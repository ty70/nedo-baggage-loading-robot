import math
import os
import fcntl
import sys
import json
import random
import time
from pathlib import Path
import numpy as np

import importlib.util
_spec = importlib.util.spec_from_file_location(
    '_nedo_v15_planner', Path(__file__).resolve().with_name('insertion_planner.py'))
_planner = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_planner)
InsertionPlanner = _planner.InsertionPlanner


# Optional 3D-BPP dump bookkeeping is intentionally file/session based rather
# than process-global. scripts.run_test launches each case in a fresh worker
# process, so module globals cannot distinguish 000/001 across cases.


def _argv_value(flag):
    """Return the value following *flag* in sys.argv, if present."""
    try:
        i = sys.argv.index(flag)
    except ValueError:
        return None
    if i + 1 >= len(sys.argv):
        return None
    v = sys.argv[i + 1]
    if str(v).startswith('--'):
        return None
    return v


class Agent:
    """search_cand_v4: first independent Extreme-Point 3D-BPP agent.

    Design goals for v01:
      - independent from safe_grid_* strategy code
      - generate geometric candidate points from floor/shelves/packed items
      - evaluate all 6 axis-aligned orientations
      - use the custom C++ checker for final AABB feasibility
      - delegate transport feasibility/order to a separate InsertionPlanner
      - keep a small, explicit heuristic score rather than hard-coded grid scans

    EP convention:
      Each EP is (x_edge, y_edge, z_bottom) where x_edge/y_edge are the
      positive-X / positive-Y outer faces of a candidate.  A box with dimensions
      (L,W,H) is placed at:
          center = (x_edge-L/2, y_edge-W/2, z_bottom+H/2)
      This makes the natural fill order back(+Y)->front(-Y), right(+X)->left(-X).
    """

    def __init__(self, module_path: str):
        self.module_path = module_path

        # Geometry / validator-aligned margins.
        self.safety_margin = 0.015
        self.extra_gap = 0.005
        self.xy_gap = self.safety_margin + self.extra_gap   # collision clearance = 0.020 m
        self.ep_gap = self.xy_gap  # dense contiguous EP spacing; currently 20 mm
        self.z_gap = 0.003
        self.start_margin = 0.01
        self.boundary_margin = 0.015
        # Exact validator inclusion threshold. sample_config.json uses -0.005 m.
        # Override only when the simulator config changes.
        self.inclusion_margin = float(os.environ.get('EP_INCLUSION_MARGIN', '-0.005'))

        # EP controls.
        self.ep_quant = 0.002      # 2 mm de-duplication cell
        self.max_eps_per_container = 400
        self.max_candidates = 6000
        # Candidate-search controls.  Full multi-start is used only when the
        # simulator provides the complete item list through optimize(); rolling
        # mode keeps the proven v5 incremental planner unchanged.
        self.search_trials = max(1, int(os.environ.get('SC_SEARCH_TRIALS', '64')))
        self.search_seed = int(os.environ.get('SC_SEARCH_SEED', '20260906'))
        self.search_max_seconds = max(1.0, float(os.environ.get('SC_SEARCH_MAX_SECONDS', '180')))
        # Dry-run insertion feasibility is evaluated for every Multi-Start
        # layout before it can win.  This is deliberately separate from BPP:
        # the final targets/orientations are never changed by the evaluator.
        self.feasibility_beam = max(1, int(os.environ.get('SC_FEASIBILITY_BEAM', '32')))
        self.feasibility_branch = max(1, int(os.environ.get('SC_FEASIBILITY_BRANCH', '16')))
        # Stage-2 search: keep several geometric packing futures alive instead
        # of committing to a single greedy EP placement at every item.
        # Small defaults intentionally limit combinatorial growth; environment
        # overrides make the search width/branching explicit and reproducible.
        self.bpp_beam = max(1, int(os.environ.get('SC_BPP_BEAM', '4')))
        self.bpp_branch = max(1, int(os.environ.get('SC_BPP_BRANCH', '3')))
        self.search_top_summary = []
        self.diagnostic_item_ids = {int(x) for x in os.environ.get('SC_DIAG_ITEMS', '38').split(',') if x.strip().isdigit()}
        self.diag_trial = 'rolling'
        self.diag_stats = {}
        # v8: optional entrance-preservation penalty. Set 0 for exact v7 scoring.
        self.rear_open_penalty = max(0.0, float(os.environ.get('SC_REAR_OPEN_PENALTY', '1.5')))
        self.rear_lane_overlap = max(0.0, float(os.environ.get('SC_REAR_LANE_OVERLAP', '0.35')))
        self.min_support_ratio = 0.90
        self.support_z_tolerance = 0.035
        self.weight_tolerance = 0.05

        # State.
        self.optimize_enabled = False
        self.lookahead_k = 1
        self.container_init = []
        self.placed_orientation = {}
        self.soft_item_ids = set()
        self.global_max_mass = None
        self.step_no = 0
        # Per-container internal placement history.  The simulator's packed_items
        # can lag by one policy call, so we keep the action we just issued and
        # merge it with settled simulator poses on the next observation.
        self.internal_packed = []
        # Explicitly remember used EP locations. This prevents an initial seed
        # from being selected again even if simulator packed_items lags.
        self.used_ep_keys = []

        # Separation state: BPP owns fixed final targets; insertion owns order.
        self.preplanned = {}          # item_id -> fixed geometric plan
        self.geometric_preplanned = {}  # complete geometry before insertion-feasibility filtering
        self.precedence_graph = None  # built by InsertionPlanner
        # Offline Multi-Start v3 stores the exact safe insertion order found by
        # the feasibility dry-run.  Rebuilding diagnostics must not silently
        # replace it with a different topological tie-break.
        self.feasibility_order = []
        self.executed_ids = set()
        self.plan_counter = 0

        # Optional 3D-BPP layout dump. The preferred CLI form is
        #   --need-3d-bpp path/to/bpp_layout.json
        # EP_NEED_3D_BPP is kept as a fallback for runners that reject unknown
        # command-line options before importing the agent module.
        dump_arg = _argv_value('--need-3d-bpp')
        dump_env = os.environ.get('EP_NEED_3D_BPP')
        self.bpp_dump_path = Path(dump_arg or dump_env).expanduser() if (dump_arg or dump_env) else None
        self.bpp_dump_task_id = None

        # C++ checker.  Keep a dedicated env var so this agent does not depend
        # on SAFE_GRID_CPP_MODE naming.
        self.cpp_mode = os.environ.get('EP_CPP_MODE', 'cpp').strip().lower()
        self.cpp_checker = None
        self.cpp_checker_path = None
        self.cpp_stats = {
            'final_cpp': 0,
            'path_cpp': 0,
            'python_fallback_final': 0,
            'python_fallback_path': 0,
            'generated_eps': 0,
            'tested_candidates': 0,
            'feasible_candidates': 0,
        }
        self._load_cpp_checker(module_path)
        self.insertion_planner = InsertionPlanner(
            path_clear_fn=self._path_clear_packed_only,
            runtime_path_clear_fn=self._validator_aligned_runtime_path_clear,
            runtime_support_fn=self._runtime_support_check,
            static_path_clear_fn=self._static_shelf_path_clear,
            shelf_lift=self.safety_margin + 0.006,
        )

    # ------------------------------------------------------------------
    # Simulator API
    # ------------------------------------------------------------------
    def get_init_states(self, init_states: dict):
        self.optimize_enabled = bool(init_states.get('optimize', False))
        self.lookahead_k = int(init_states.get('lookahead_k', 1))
        self.container_init = init_states.get('container_list', [])
        self.placed_orientation = {}
        self.soft_item_ids = set()
        self.global_max_mass = None
        self.step_no = 0
        self.internal_packed = [[] for _ in self.container_init]
        self.used_ep_keys = [set() for _ in self.container_init]
        self.preplanned = {}
        self.geometric_preplanned = {}
        self.precedence_graph = None
        self.feasibility_order = []
        self.executed_ids = set()
        self.plan_counter = 0
        self.diag_stats = {}
        self._init_bpp_dump_task(init_states)
        for k in self.cpp_stats:
            self.cpp_stats[k] = 0
        print(
            f'[search_cand_v5][init] boundary_margin={self.boundary_margin:.3f} '
            f'xy_gap={self.xy_gap:.3f} ep_gap={self.ep_gap:.3f} '
            f'inclusion_margin={self.inclusion_margin:.3f} cpp_mode={self.cpp_mode} '
            f'search_trials={self.search_trials} search_budget={self.search_max_seconds:.1f}s '
            f'bpp_beam={self.bpp_beam} bpp_branch={self.bpp_branch} '
            f'feasibility_beam={self.feasibility_beam} feasibility_branch={self.feasibility_branch} '
            f'rear_open_penalty={self.rear_open_penalty:.2f} rear_lane_overlap={self.rear_lane_overlap:.2f}',
            flush=True
        )
        return True

    def optimize(self, item_list: list):
        """Plan the full packing layout first, then return insertion order.

        When the simulator enables optimize(), this is the cleanest separation:
        3D-BPP fixes every reachable final target using geometry only, then the
        InsertionPlanner derives a precedence graph from those fixed targets.
        """
        self._register_item_metadata(item_list)
        base_order = self._cargo_order_items(item_list)
        self._search_full_geometric_plan(item_list, self.container_init, source='optimize')
        self._dump_bpp_layout(self.container_init, stage='optimize')
        self._rebuild_precedence(self.container_init)

        planned_order = []
        if self.feasibility_order:
            planned_order = [
                int(iid) for iid in self.feasibility_order
                if int(iid) in self.preplanned
            ]
        elif self.precedence_graph is not None:
            planned_order = [
                iid for iid in self.precedence_graph.get('order', [])
                if iid in self.preplanned
            ]
        # Keep simulator API total: any item that BPP could not place is appended
        # after the planned set instead of being silently dropped.
        seen = set(planned_order)
        planned_order.extend(int(it['index']) for it in base_order if int(it['index']) not in seen)
        print(
            f'[search_cand_v5][INSERT-ORDER] mode=full order={planned_order} '
            f'cycles={self.precedence_graph.get("cyclic", []) if self.precedence_graph else []}',
            flush=True,
        )
        return planned_order

    def policy(self, observation: dict):
        pool = observation.get('pool_list', [])
        containers = observation.get('container_list', [])
        if not pool or not containers:
            return self._safe_abort_no_transport(
                containers[0] if containers else None,
                pool,
                reason='MISSING-POOL-OR-CONTAINER'
            )

        self.step_no += 1
        self._register_item_metadata(pool)

        # Only online-only tasks may extend the BPP plan from newly visible
        # items.  When optimize() already saw the complete stream, the offline
        # BPP selection is final: items that were not adopted by that layout are
        # deliberately never reintroduced later.
        if not self.optimize_enabled:
            missing = [it for it in self._cargo_order_items(pool) if int(it['index']) not in self.preplanned]
            if missing:
                self._extend_geometric_plan(missing, containers, source='rolling')
                self._dump_bpp_layout(containers, stage='rolling')
                self._rebuild_precedence(containers)

        visible_plans = []
        pool_index_by_id = {}
        for pidx, raw in enumerate(pool):
            iid = int(raw['index'])
            pool_index_by_id[iid] = pidx
            plan = self.preplanned.get(iid)
            if plan is not None and iid not in self.executed_ids:
                visible_plans.append(plan)

        if not visible_plans:
            # The simulator's set_item_order() requires a complete permutation
            # and env.step() has no skip/no-op action. Once the offline plans
            # are exhausted, attempt a real-time, collision-checked placement
            # of the *currently visible* unplanned item before terminating.
            missing = [it for it in self._cargo_order_items(pool)
                       if int(it['index']) not in self.preplanned
                       and int(it['index']) not in self.executed_ids]
            print(
                f'[V10-UNPLANNED] step={self.step_no} '
                f'visible={[int(x["index"]) for x in pool]} '
                f'missing={[int(x["index"]) for x in missing]} '
                f'pending_plans={len(self.preplanned)-len(self.executed_ids)}',
                flush=True,
            )
            if missing:
                self._extend_geometric_plan(missing, containers, source='runtime_replan')
                newly_planned = [int(it['index']) for it in missing
                                 if int(it['index']) in self.preplanned]
                print(f'[V10-REPLAN] step={self.step_no} '
                      f'created={newly_planned}', flush=True)
                if newly_planned:
                    self._rebuild_precedence(containers)
                    self._dump_bpp_layout(containers, stage='runtime_replan')
                    visible_plans = [self.preplanned[int(it['index'])]
                                     for it in pool
                                     if int(it['index']) in self.preplanned
                                     and int(it['index']) not in self.executed_ids]
            if not visible_plans:
                print(f'[V10-REPLAN-FAILED] step={self.step_no} '
                      f'visible={[int(x["index"]) for x in pool]}', flush=True)
                return self._safe_abort_no_transport(
                    containers[0], pool, reason='NO-BPP-PLAN-AFTER-REPLAN'
                )

        packed_by_container = {
            i: self._effective_packed(i, c) for i, c in enumerate(containers)
        }
        placed_ids = set(self.executed_ids)
        for packed in packed_by_container.values():
            for obj in packed:
                if obj.get('index') is not None:
                    placed_ids.add(int(obj['index']))

        selected = self.insertion_planner.choose_runtime(
            visible_plans,
            containers,
            packed_by_container,
            graph=self.precedence_graph,
            placed_ids=placed_ids,
        )

        if selected is None:
            order = self.precedence_graph.get('order', []) if self.precedence_graph else []
            diag = getattr(self.insertion_planner, 'last_runtime_diagnostics', {}) or {}
            print(
                f'[search_cand_v5][INSERT] step={self.step_no} NO-SAFE-EXECUTABLE-PLAN '
                f'visible={[int(p["item_id"]) for p in visible_plans]} order={order} '
                f'static_blocked={diag.get("static_blocked_ids", [])} '
                f'blocked_meta={diag.get("blocked_meta", [])}',
                flush=True,
            )
            # Rebuild once from the still-pending fixed BPP plans.  This is not
            # a geometric re-plan: final_target/orientation stay untouched.  It
            # only refreshes insertion dependencies after earlier actions have
            # been issued during get_init_states()/rolling lookahead.
            self._rebuild_precedence(containers)
            selected = self.insertion_planner.choose_runtime(
                visible_plans,
                containers,
                packed_by_container,
                graph=self.precedence_graph,
                placed_ids=placed_ids,
            )
            if selected is None:
                # Keep the completed v5 separation: if an item belongs to the
                # fixed BPP layout but the conservative runtime planner cannot
                # certify a route, execute the fixed BPP target as the last
                # resort.  Unplanned items never reach this branch because they
                # are filtered out of visible_plans above.
                return self._planned_layout_last_resort(
                    visible_plans, pool_index_by_id, containers, pool
                )

        plan, execution_pos, insert_meta = selected
        insert_meta = dict(insert_meta)
        insert_meta['precedence_bypass'] = False
        insert_meta.setdefault('forced', False)

        iid = int(plan['item_id'])
        pidx = int(pool_index_by_id[iid])
        ori = int(plan['orientation'])
        final_pos = tuple(float(v) for v in plan['final_target'])
        execution_pos = tuple(float(v) for v in execution_pos)
        item = plan['item']
        cidx = int(plan['container_idx'])

        # Priority-A safety gate:
        # Validate the actual pose returned to the simulator.  The BPP layout
        # validates final_target, but insertion_planner may add a temporary
        # shelf_lift or another execution offset.  Sending that unchecked pose
        # can therefore cross a container boundary even when final_target is
        # valid.  If the execution pose is outside, keep the fixed BPP plan and
        # fall back to its already-validated final target.
        if not self._inside_container(containers[cidx], item, execution_pos):
            print(
                f'[search_cand_v5][EXEC-INCLUSION-REJECT] '
                f'step={self.step_no} item={iid} '
                f'final_target=({final_pos[0]:.3f},{final_pos[1]:.3f},{final_pos[2]:.3f}) '
                f'execution_target=({execution_pos[0]:.3f},{execution_pos[1]:.3f},{execution_pos[2]:.3f}) '
                f'shelf_lift={float(insert_meta.get("shelf_lift", 0.0)):.3f} '
                f'action=fallback-final-target',
                flush=True,
            )
            execution_pos = final_pos
            insert_meta['execution_inclusion_rejected'] = True
            insert_meta['execution_fallback'] = 'final_target'
        else:
            insert_meta['execution_inclusion_rejected'] = False
            insert_meta['execution_fallback'] = None

        # Final safety clamp to prevent 'not inside' from floating point drift.
        execution_pos = self._clamp_to_safe_margin(containers[cidx], item, execution_pos, ori)

        # Check the FINAL issued coordinate, not just the planner's proposed
        # coordinate. An X/Z clamp changes the approach trajectory.
        occupied = packed_by_container[cidx]
        if not self._inside_container(containers[cidx], item, execution_pos) or not self._actual_simulator_entry_clear(
                containers[cidx], item, execution_pos, occupied):
            fallback = self._clamp_to_safe_margin(containers[cidx], item, final_pos, ori)
            if (self._inside_container(containers[cidx], item, fallback) and
                    self._actual_simulator_entry_clear(containers[cidx], item, fallback, occupied)):
                print(f'[search_cand_v6][ENTRY-FALLBACK] item={iid} execution->final', flush=True)
                execution_pos = fallback
            else:
                print(f'[search_cand_v6][ENTRY-REJECT] item={iid} no-safe-path', flush=True)
                return self._safe_abort_no_transport(containers[0], pool, reason='ENTRY-PATH-BLOCKED')

        self.placed_orientation[iid] = ori
        self.executed_ids.add(iid)

        ep = plan['ep']
        while len(self.used_ep_keys) <= cidx:
            self.used_ep_keys.append(set())
        self.used_ep_keys[cidx].add(self._ep_location_key(ep))
        # Internal geometry records the BPP final target, not temporary shelf lift.
        self._record_internal_placement(cidx, containers[cidx], item, final_pos, ori)

        print(
            f'[search_cand_v5][PACK] step={self.step_no} item={iid} plan_rank={plan["plan_rank"]} '
            f'ori={ori} final_target=({final_pos[0]:.3f},{final_pos[1]:.3f},{final_pos[2]:.3f}) '
            f'ep=({ep[0]:.3f},{ep[1]:.3f},{ep[2]:.3f},{ep[3] if len(ep)>=4 else "?"}) '
            f'support={plan["support_kind"]} score={plan["score"]:.5f}',
            flush=True,
        )
        print(
            f'[search_cand_v5][INSERT] step={self.step_no} item={iid} '
            f'execution_target=({execution_pos[0]:.3f},{execution_pos[1]:.3f},{execution_pos[2]:.3f}) '
            f'path_ok={insert_meta.get("path_ok")} shelf_lift={insert_meta.get("shelf_lift",0.0):.3f} '
            f'forced={insert_meta.get("forced", False)} precedence_bypass={insert_meta.get("precedence_bypass", False)} '
            f'support_runtime={insert_meta.get("support_meta", {})}',
            flush=True,
        )

        return {
            'item_idx': pidx,
            'container_idx': cidx,
            'place_pos': np.asarray(execution_pos, dtype=np.float32),
            'orientation': ori,
        }

    def _init_bpp_dump_task(self, init_states):
        """Allocate a stable task key and initialize the optional dump file.

        ``scripts.run_test`` creates a fresh worker process per case.  Therefore
        process-local counters reset for every case and cannot be used to name
        000/001.  Use a tiny sidecar containing the runner parent PID instead:

        * first case of a new run (different parent PID) resets the JSON;
        * later cases in the same run preserve it and take the next free key.

        This changes dump bookkeeping only; packing/insertion logic is untouched.
        """
        if self.bpp_dump_path is None:
            return

        path = self.bpp_dump_path.resolve()
        path.parent.mkdir(parents=True, exist_ok=True)
        session_path = path.with_suffix(path.suffix + '.session')
        parent_pid = str(os.getppid())

        # Prefer an explicit simulator task/case id if one exists.
        explicit = None
        for name in ('task_id', 'case_id', 'task_idx', 'case_idx'):
            if init_states.get(name) is not None:
                explicit = str(init_states.get(name))
                break

        # New scripts.run_test invocation: clear only the dump output, never any
        # planner state.  Child workers for 000 and 001 share the same parent PID.
        previous_session = None
        try:
            previous_session = session_path.read_text(encoding='utf-8').strip()
        except Exception:
            pass
        if previous_session != parent_pid:
            path.write_text('{}\n', encoding='utf-8')
            session_path.write_text(parent_pid + '\n', encoding='utf-8')

        try:
            current = json.loads(path.read_text(encoding='utf-8')) if path.exists() else {}
        except Exception:
            current = {}

        if explicit is not None:
            if explicit.isdigit():
                self.bpp_dump_task_id = f'{int(explicit):03d}'
            else:
                self.bpp_dump_task_id = explicit
        else:
            used = set(str(k) for k in current.keys())
            n = 0
            while f'{n:03d}' in used:
                n += 1
            self.bpp_dump_task_id = f'{n:03d}'

        self._dump_bpp_layout(init_states.get('container_list', []) or [], stage='init')
        print(
            f'[search_cand_v5][BPP-DUMP] task={self.bpp_dump_task_id} path={path}',
            flush=True,
        )

    def _bpp_container_json(self, c, cidx):
        """Container fields required by the visualizer plus useful geometry."""
        center = c.get('center', (0.0, 0.0, 0.0))
        return {
            'index': int(c.get('index', cidx)),
            'length': float(c['length']),
            'width': float(c['width']),
            'height': float(c['height']),
            'center': [float(center[0]), float(center[1]), float(center[2])],
            'thickness': float(c.get('thickness', 0.04)),
            'buffer': float(c.get('buffer', 0.0)),
            'cut_x': float(c.get('cut_x', 0.0)),
            'cut_y': float(c.get('cut_y', 0.0)),
            'require_shelf': bool(c.get('shelf', c.get('require_shelf', False))),
            'is_prioritized': bool(c.get('is_prioritized', False)),
        }

    def _bpp_plan_json(self, plan, c):
        """Serialize one fixed BPP reservation, independent of insertion order."""
        item = plan['item']
        target = tuple(float(v) for v in plan['final_target'])
        center = c.get('center', (0.0, 0.0, 0.0))
        # Simulator local_to_global() adds the container X offset only.
        world_pos = [
            target[0] + float(center[0]),
            target[1],
            target[2],
        ]
        return {
            'index': int(plan['item_id']),
            'pos': world_pos,
            'local_pos': list(target),
            'orientation': int(plan['orientation']),
            'length': float(item['length']),
            'width': float(item['width']),
            'height': float(item['height']),
            'mass': float(item.get('mass', 0.0)),
            'is_prioritized': bool(item.get('is_prioritized', False)),
            'is_soft': bool(item.get('is_soft', False)),
            'plan_rank': int(plan.get('plan_rank', -1)),
            'support_kind': str(plan.get('support_kind', 'none')),
            'support_item_id': (
                None if plan.get('support_item_id') is None
                else int(plan.get('support_item_id'))
            ),
            'support_ratio': float(plan.get('support_ratio', 0.0)),
            'score': float(plan.get('score', 0.0)),
            'source': str(plan.get('source', 'unknown')),
        }

    def _dump_bpp_layout(self, containers, stage='update'):
        """Save executable and full geometric layouts in the same JSON task."""
        if self.bpp_dump_path is None or self.bpp_dump_task_id is None:
            return
        path = self.bpp_dump_path.resolve()
        path.parent.mkdir(parents=True, exist_ok=True)

        def serialize(plans):
            result = {str(int(c.get('index', i))): [] for i, c in enumerate(containers)}
            order = []
            for iid, plan in sorted(
                plans.items(),
                key=lambda kv: (int(kv[1].get('plan_rank', 10**9)), int(kv[0])),
            ):
                cidx = int(plan['container_idx'])
                if not 0 <= cidx < len(containers):
                    continue
                cid = str(int(containers[cidx].get('index', cidx)))
                result.setdefault(cid, []).append(
                    self._bpp_plan_json(plan, containers[cidx])
                )
                order.append(int(iid))
            return result, order

        safe_placements, safe_order = serialize(self.preplanned)
        source_geom = self.geometric_preplanned if self.geometric_preplanned else self.preplanned
        geom_placements, geom_order = serialize(source_geom)
        safe_ids = set(safe_order)
        blocked_ids = [iid for iid in geom_order if iid not in safe_ids]
        record = {
            'kind': '3d-bpp-layout',
            'stage': str(stage),
            'placements': safe_placements,
            'geometric_placements': geom_placements,
            'container_list': [self._bpp_container_json(c, i) for i, c in enumerate(containers)],
            'bpp_order': safe_order,
            'geometric_bpp_order': geom_order,
            'num_planned_items': len(safe_order),
            'num_geometric_items': len(geom_order),
            'blocked_item_ids': blocked_ids,
            'note': ('placements: feasible subset; geometric_placements: full geometry '
                     'from the same selected search layout, before insertion filtering. '
                     'The extra boxes are hypothetical, not proven transportable.'),
        }
        lock_path = path.with_suffix(path.suffix + '.lock')
        with open(lock_path, 'w') as lock_f:
            fcntl.flock(lock_f, fcntl.LOCK_EX)
            try:
                data = json.loads(path.read_text(encoding='utf-8')) if path.exists() else {}
                if not isinstance(data, dict):
                    data = {}
            except Exception:
                data = {}
            data[str(self.bpp_dump_task_id)] = record
            tmp = path.with_suffix(path.suffix + '.tmp')
            tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
            os.replace(tmp, path)
        print(
            f'[search_cand_v8][BPP-DUMP] task={self.bpp_dump_task_id} stage={stage} '
            f'safe={len(safe_order)} geometric={len(geom_order)} blocked={blocked_ids} '
            f'path={path}', flush=True
        )

    def _register_item_metadata(self, items):
        masses = [float(it.get('mass', 0.0)) for it in items]
        if masses:
            m = max(masses)
            self.global_max_mass = m if self.global_max_mass is None else max(self.global_max_mass, m)
        for it in items:
            if bool(it.get('is_soft', False)) and it.get('index') is not None:
                self.soft_item_ids.add(int(it['index']))

    def _cargo_order_items(self, item_list):
        """Deterministic BPP construction order; not the execution order."""
        def category(it):
            soft = bool(it.get('is_soft', False))
            pri = bool(it.get('is_prioritized', False))
            if not soft and not pri:
                return 0
            if not soft and pri:
                return 1
            if soft and not pri:
                return 2
            return 3
        return sorted(
            list(item_list),
            key=lambda it: (
                category(it),
                -float(it.get('mass', 0.0)),
                -(float(it['length']) * float(it['width'])),
                -float(it['height']),
                int(it['index']),
            ),
        )

    def _reserved_plan_records(self, cidx):
        """Return every fixed BPP reservation for this container.

        v2 deliberately does *not* drop reservations merely because an action
        has already been issued.  During get_init_states()/rolling lookahead,
        simulator packed_items can lag the action stream, so using
        ``executed_ids`` here can temporarily make a fixed target look empty and
        allow a newly visible item to reserve the same pose.  We keep all
        preplanned poses reserved and de-duplicate them against observed/internal
        geometry by item id when constructing the occupied set.
        """
        out = []
        for iid, plan in self.preplanned.items():
            if int(plan['container_idx']) != int(cidx):
                continue
            rec = plan.get('packed_record')
            if rec is not None:
                out.append(dict(rec))
        return out

    # ------------------------------------------------------------------
    # Candidate search for offline 3D-BPP
    # ------------------------------------------------------------------
    def _search_order_variants(self, item_list):
        """Return deterministic and seeded construction orders for Multi-Start.

        The existing v5 category partition is retained as the first key so the
        search does not casually move soft/priority handling into a completely
        different regime.  Multi-Start changes only the order *within* those
        categories and therefore explores packing futures without changing the
        underlying feasibility or rule checks.
        """
        items = list(item_list)

        def category(it):
            soft = bool(it.get('is_soft', False))
            pri = bool(it.get('is_prioritized', False))
            if not soft and not pri:
                return 0
            if not soft and pri:
                return 1
            if soft and not pri:
                return 2
            return 3

        def dims(it):
            a = float(it['length'])
            b = float(it['width'])
            c = float(it['height'])
            return a, b, c

        def current_key(it):
            a, b, c = dims(it)
            return (category(it), -float(it.get('mass', 0.0)), -(a*b), -c, int(it['index']))

        def volume(it):
            return math.prod(dims(it))

        def footprint(it):
            a, b, _ = dims(it)
            return a * b

        def density(it):
            v = volume(it)
            return float(it.get('mass', 0.0)) / v if v > 1e-12 else 0.0

        def min_edge(it):
            return min(dims(it))

        def aspect_ratio(it):
            ds = dims(it)
            lo = min(ds)
            return max(ds) / lo if lo > 1e-12 else float('inf')

        # Deterministic seeds cover qualitatively different construction biases.
        # Category order remains fixed; only the ordering inside each category
        # changes, preserving the established handling of soft/prioritized items.
        strategies = [
            ('base', sorted(items, key=current_key)),
            ('mass_desc', sorted(items, key=lambda it: (
                category(it), -float(it.get('mass', 0.0)), -volume(it), -footprint(it), int(it['index'])
            ))),
            ('volume_desc', sorted(items, key=lambda it: (
                category(it), -volume(it), -float(it.get('mass', 0.0)), int(it['index'])
            ))),
            ('footprint_desc', sorted(items, key=lambda it: (
                category(it), -footprint(it), -volume(it), int(it['index'])
            ))),
            ('max_edge_desc', sorted(items, key=lambda it: (
                category(it), -max(dims(it)), -volume(it), int(it['index'])
            ))),
            ('min_edge_desc', sorted(items, key=lambda it: (
                category(it), -min_edge(it), -volume(it), int(it['index'])
            ))),
            ('height_desc', sorted(items, key=lambda it: (
                category(it), -dims(it)[2], -volume(it), int(it['index'])
            ))),
            ('height_asc', sorted(items, key=lambda it: (
                category(it), dims(it)[2], -volume(it), int(it['index'])
            ))),
            ('density_desc', sorted(items, key=lambda it: (
                category(it), -density(it), -volume(it), int(it['index'])
            ))),
            ('compact_desc', sorted(items, key=lambda it: (
                category(it), -(volume(it) / max(dims(it))**3 if max(dims(it)) > 1e-12 else 0.0),
                -volume(it), int(it['index'])
            ))),
            ('slender_desc', sorted(items, key=lambda it: (
                category(it), -aspect_ratio(it), -volume(it), int(it['index'])
            ))),
            ('small_first', sorted(items, key=lambda it: (
                category(it), volume(it), footprint(it), int(it['index'])
            ))),
        ]

        # De-duplicate structured variants first.
        unique = []
        seen = set()
        for name, order in strategies:
            sig = tuple(int(it['index']) for it in order)
            if sig in seen:
                continue
            seen.add(sig)
            unique.append((name, order))
            if len(unique) >= self.search_trials:
                return unique

        # Then keep generating seeded within-category permutations until the
        # requested number of *distinct* trials is reached (or a conservative
        # attempt limit is hit on tiny scenes where few permutations exist).
        attempt = 0
        max_attempts = max(self.search_trials * 32, 256)
        while len(unique) < self.search_trials and attempt < max_attempts:
            seed = self.search_seed + attempt
            rng = random.Random(seed)
            ordered = []
            for cat in range(4):
                group = [it for it in items if category(it) == cat]
                rng.shuffle(group)
                ordered.extend(group)
            sig = tuple(int(it['index']) for it in ordered)
            attempt += 1
            if sig in seen:
                continue
            seen.add(sig)
            unique.append((f'seed_{seed}', ordered))
        return unique

    def _find_top_candidates_local(
        self, raw_item, containers, planned_packed, local_used, limit=None
    ):
        """Return several best v5-feasible EP placements for one search state.

        v3 committed to exactly one candidate.  v4 preserves the same geometry,
        support, static-path and C++/Python feasibility checks, but exposes the
        top few distinct candidates so the caller can keep multiple packing
        futures alive in a small beam.
        """
        limit = self.bpp_branch if limit is None else max(1, int(limit))
        tested = 0
        feasible = 0
        diag = int(raw_item['index']) in self.diagnostic_item_ids
        reasons = {'inside': 0, 'shelf': 0, 'support': 0,
                   'collision': 0, 'static_path': 0, 'accepted': 0,
                   'duplicate': 0, 'ep_total': 0}

        # Keep the established ordinary-EP preference.  Projected EPs are used
        # only when the ordinary phase has no feasible placement, matching v3.
        for ep_phase in ('ordinary', 'projected'):
            candidates = []
            seen = set()
            for cidx, c in enumerate(containers):
                packed = planned_packed[cidx]
                eps_all = self._generate_extreme_points(c, packed)
                eps = [ep for ep in eps_all if self._ep_location_key(ep) not in local_used[cidx]]
                if ep_phase == 'ordinary':
                    eps = [ep for ep in eps if ':proj:' not in str(ep[3] if len(ep) >= 4 else '')]
                else:
                    eps = [ep for ep in eps if ':proj:' in str(ep[3] if len(ep) >= 4 else '')]

                if diag:
                    reasons['ep_total'] += len(eps)
                for item in self._oriented_variants(raw_item):
                    for ep in eps:
                        tested += 1
                        cand = self._center_from_ep(ep, item)
                        if not self._inside_container(c, item, cand):
                            if diag: reasons['inside'] += 1
                            continue
                        if self._intersects_shelf_plate(c, item, cand):
                            if diag: reasons['shelf'] += 1
                            continue
                        support = self._support_info(c, item, cand, packed)
                        if not support['ok']:
                            if diag: reasons['support'] += 1
                            continue
                        if not self._final_clear(
                            c, item, cand, packed,
                            support_obj=support.get('support_obj'),
                        ):
                            if diag: reasons['collision'] += 1
                            continue

                        static_target = tuple(float(v) for v in cand)
                        if support.get('kind') in ('small-shelf', 'main-shelf'):
                            static_target = (
                                static_target[0], static_target[1],
                                static_target[2] + self.insertion_planner.shelf_lift,
                            )
                        if not self._static_shelf_path_clear(c, item, static_target):
                            if diag: reasons['static_path'] += 1
                            continue
                        if not self._bpp_required_support_path_clear(c, item, cand, support):
                            if diag: reasons['static_path'] += 1
                            continue

                        feasible += 1
                        if diag: reasons['accepted'] += 1
                        score = self._score_candidate(
                            c, raw_item, item, cand, ep, support, packed
                        )
                        tie = (
                            float(score),
                            int(item['_orientation']),
                            int(cidx),
                            float(cand[2]),
                            -float(cand[1]),
                            -float(cand[0]),
                        )
                        # Multiple EP labels can quantize to the same physical
                        # placement.  Do not waste beam slots on duplicates.
                        key = (
                            int(cidx),
                            int(item['_orientation']),
                            round(float(cand[0]), 6),
                            round(float(cand[1]), 6),
                            round(float(cand[2]), 6),
                        )
                        if key in seen:
                            if diag: reasons['duplicate'] += 1
                            continue
                        seen.add(key)
                        candidates.append((
                            tie,
                            (float(score), int(cidx), tuple(float(v) for v in cand),
                             dict(item), tuple(ep), dict(support)),
                        ))

            if candidates:
                candidates.sort(key=lambda x: x[0])
                if diag:
                    self._diag_emit(raw_item, ep_phase, reasons, tested, feasible,
                                    len(candidates), limit)
                return [x[1] for x in candidates[:limit]], tested, feasible

        if diag:
            self._diag_emit(raw_item, 'none', reasons, tested, feasible, 0, limit)
        return [], tested, feasible

    def _diag_emit(self, item, phase, reasons, tested, feasible, candidates, limit):
        iid = int(item['index'])
        key = (str(self.diag_trial), iid)
        stats = self.diag_stats.setdefault(key, {
            'calls': 0, 'with_candidates': 0, 'without_candidates': 0,
            'tested': 0, 'feasible': 0,
            'reason_totals': {k: 0 for k in reasons}
        })
        stats['calls'] += 1
        stats['with_candidates' if candidates else 'without_candidates'] += 1
        stats['tested'] += tested
        stats['feasible'] += feasible
        for k, v in reasons.items():
            stats['reason_totals'][k] += v
        print(f'[DIAG-ITEM] trial={self.diag_trial} item={iid} '
              f'phase={phase} tested={tested} feasible={feasible} '
              f'candidates={candidates} retained_per_state={min(limit,candidates)} '
              f'reject={reasons}', flush=True)

    def _find_best_candidate_local(self, raw_item, containers, planned_packed, local_used):
        """Compatibility wrapper for incremental/rolling code paths."""
        candidates, tested, feasible = self._find_top_candidates_local(
            raw_item, containers, planned_packed, local_used, limit=1
        )
        return (candidates[0] if candidates else None), tested, feasible

    def _clone_beam_state(self, state):
        return {
            'planned_packed': {
                cidx: list(packed)
                for cidx, packed in state['planned_packed'].items()
            },
            'local_used': {
                cidx: set(used)
                for cidx, used in state['local_used'].items()
            },
            'plans': dict(state['plans']),
            'rank': int(state['rank']),
            'pending': [dict(it) for it in state['pending']],
            'total_tested': int(state['total_tested']),
            'total_feasible': int(state['total_feasible']),
            'retry_rounds': int(state['retry_rounds']),
            'placed_this_round': int(state['placed_this_round']),
            'deferred_final': list(state.get('deferred_final', [])),
            'score_sum': float(state.get('score_sum', 0.0)),
        }

    def _beam_state_metrics(self, state):
        """Cheap deterministic key used to prune partial geometric states."""
        plans = state['plans']
        if not plans:
            return (0.0, 0, 0.0, 0.0)
        volume = 0.0
        weighted_z = 0.0
        mass_total = 0.0
        for plan in plans.values():
            it = plan['item']
            v = (
                float(it['length'])
                * float(it['width'])
                * float(it['height'])
            )
            volume += v
            mass = float(it.get('mass', 0.0))
            mass_total += mass
            weighted_z += mass * float(plan['final_target'][2])
        cog_z = weighted_z / mass_total if mass_total > 1e-12 else 0.0
        return (
            float(volume),
            int(len(plans)),
            -float(cog_z),
            -float(state.get('score_sum', 0.0)),
        )

    def _dedup_and_prune_beam(self, states):
        """Deduplicate identical geometric futures and retain the best beam."""
        if not states:
            return []
        states.sort(key=self._beam_state_metrics, reverse=True)
        unique = []
        seen = set()
        for st in states:
            sig = tuple(sorted(
                (
                    int(iid),
                    int(plan['container_idx']),
                    int(plan['orientation']),
                    round(float(plan['final_target'][0]), 4),
                    round(float(plan['final_target'][1]), 4),
                    round(float(plan['final_target'][2]), 4),
                )
                for iid, plan in st['plans'].items()
            ))
            if sig in seen:
                continue
            seen.add(sig)
            unique.append(st)
            if len(unique) >= self.bpp_beam:
                break
        return unique

    def _build_layout_for_order(self, items, containers, source='optimize'):
        """Construct several EP layouts with Deferred Retry + geometric beam.

        Every item expands each surviving state by up to ``bpp_branch`` valid
        placements.  The best ``bpp_beam`` partial layouts survive.  If an item
        has no placement in a state it is deferred; after a pass that placed at
        least one item, deferred items are retried against the newly changed EP
        geometry.  This is deliberately a *small* beam, not exhaustive search.
        """
        initial_packed = {}
        initial_used = {}
        for cidx, c in enumerate(containers):
            initial_packed[cidx] = list(
                self._oriented_packed(c.get('packed_items', []) or [])
            )
            initial_used[cidx] = set()

        frontier = [{
            'planned_packed': initial_packed,
            'local_used': initial_used,
            'plans': {},
            'rank': 0,
            'pending': [dict(it) for it in items],
            'total_tested': 0,
            'total_feasible': 0,
            'retry_rounds': 0,
            'placed_this_round': 0,
            'deferred_final': [],
            'score_sum': 0.0,
        }]

        completed = []
        max_rounds = max(1, len(items) + 1)

        for _ in range(max_rounds):
            if not frontier:
                break

            pass_results = []

            for root in frontier:
                root = self._clone_beam_state(root)
                root['retry_rounds'] += 1
                root['placed_this_round'] = 0
                current = root['pending']
                root['pending'] = []
                local_frontier = [root]

                for raw_item in current:
                    expanded = []
                    for st in local_frontier:
                        candidates, tested, feasible = self._find_top_candidates_local(
                            raw_item,
                            containers,
                            st['planned_packed'],
                            st['local_used'],
                            limit=self.bpp_branch,
                        )
                        # Stats are attached to each child so that the selected
                        # terminal branch carries the work that produced it.
                        if not candidates:
                            child = self._clone_beam_state(st)
                            child['total_tested'] += tested
                            child['total_feasible'] += feasible
                            child['pending'].append(dict(raw_item))
                            expanded.append(child)
                            continue

                        for score, cidx, pos, item, ep, support in candidates:
                            child = self._clone_beam_state(st)
                            child['total_tested'] += tested
                            child['total_feasible'] += feasible
                            iid = int(raw_item['index'])
                            ori = int(item['_orientation'])
                            support_obj = support.get('support_obj')
                            support_item_id = None
                            if support_obj is not None and support_obj.get('index') is not None:
                                support_item_id = int(support_obj['index'])

                            rec = self._make_planned_packed_record(
                                containers[cidx], item, pos, ori
                            )
                            child['plans'][iid] = {
                                'item_id': iid,
                                'container_idx': int(cidx),
                                'final_target': tuple(float(v) for v in pos),
                                'orientation': ori,
                                'item': dict(item),
                                'ep': tuple(ep),
                                'support_kind': support['kind'],
                                'support_ratio': float(support['ratio']),
                                'support_item_id': support_item_id,
                                'score': float(score),
                                'plan_rank': int(child['rank']),
                                'packed_record': rec,
                                'source': source,
                            }
                            child['rank'] += 1
                            child['planned_packed'][cidx].append(rec)
                            child['local_used'][cidx].add(self._ep_location_key(ep))
                            child['placed_this_round'] += 1
                            child['score_sum'] += float(score)
                            expanded.append(child)

                    if int(raw_item['index']) in self.diagnostic_item_ids:
                        with_item = sum(int(raw_item['index']) in st['plans'] for st in expanded)
                        print(f'[DIAG-BEAM] trial={self.diag_trial} item={raw_item["index"]} '
                              f'before_prune={len(expanded)} placed_branches={with_item}', flush=True)
                    local_frontier = self._dedup_and_prune_beam(expanded)
                    if int(raw_item['index']) in self.diagnostic_item_ids:
                        with_item = sum(int(raw_item['index']) in st['plans'] for st in local_frontier)
                        print(f'[DIAG-BEAM] trial={self.diag_trial} item={raw_item["index"]} '
                              f'after_prune={len(local_frontier)} placed_branches={with_item}', flush=True)
                    if not local_frontier:
                        break

                pass_results.extend(local_frontier)

            pass_results = self._dedup_and_prune_beam(pass_results)
            if not pass_results:
                break

            completed.extend([st for st in pass_results if not st['pending']])
            retry_frontier = [st for st in pass_results if st['pending']]
            if not retry_frontier:
                break

            productive = [
                st for st in retry_frontier
                if st['placed_this_round'] > 0
            ]
            if not productive:
                for st in retry_frontier:
                    st['deferred_final'] = [
                        int(it['index']) for it in st['pending']
                    ]
                completed.extend(retry_frontier)
                break

            frontier = self._dedup_and_prune_beam(productive)

        if not completed:
            completed = frontier or []

        completed = self._dedup_and_prune_beam(completed)
        for iid in sorted(self.diagnostic_item_ids):
            n = sum(iid in st['plans'] for st in completed)
            print(f'[DIAG-RESULT] trial={self.diag_trial} item={iid} '
                  f'completed_branches={len(completed)} placed_branches={n}', flush=True)
        layouts = []
        for st in completed:
            metrics = self._layout_metrics(st['plans'])
            deferred_final = st.get('deferred_final') or [
                int(it['index']) for it in st.get('pending', [])
            ]
            layouts.append({
                'plans': dict(st['plans']),
                'metrics': metrics,
                'tested': int(st['total_tested']),
                'feasible': int(st['total_feasible']),
                'retry_rounds': int(st['retry_rounds']),
                'deferred_final': list(deferred_final),
                'beam_score': self._beam_state_metrics(st),
            })

        if not layouts:
            layouts = [{
                'plans': {},
                'metrics': (0.0, 0, float('-inf'), float('-inf')),
                'tested': 0,
                'feasible': 0,
                'retry_rounds': 0,
                'deferred_final': [int(it['index']) for it in items],
                'beam_score': (0.0, 0, 0.0, 0.0),
            }]

        layouts.sort(key=lambda r: r['metrics'], reverse=True)
        best = dict(layouts[0])
        best['beam_layouts'] = layouts
        return best

    def _evaluate_insertion_feasibility(self, plans, containers):
        """Dry-run the fixed BPP layout through insertion constraints.

        This evaluator does not move, resize or re-pack anything.  It asks a
        different question from geometric BPP: starting from an empty cargo
        space, what subset of these *fixed* targets can be reached safely in a
        consistent insertion sequence?

        A small beam is used because the first executable item is not always
        the best one.  States with the same placed-id set are equivalent for
        future collision checks (all poses are fixed), so they are deduplicated
        aggressively.  The result therefore catches route/support deadlocks
        such as the v1 item18 case before Multi-Start chooses the layout.
        """
        plans = dict(plans)
        if not plans:
            return {
                'safe_ids': [], 'safe_order': [], 'blocked_ids': [],
                'metrics': (0.0, 0, float('-inf'), float('-inf')),
                'graph': self.insertion_planner.build_precedence([], containers),
                'beam_states': 0,
            }

        graph = self.insertion_planner.build_precedence(list(plans.values()), containers)
        # v14: independent insertion diagnostics for 2, 7 and 16.
        # No optimization, packing, feasibility or pruning rules are changed.
        diag_ids = {int(x) for x in os.environ.get('SC_ORDER_DIAG_ITEMS', '2,7,16').split(',') if x.strip().isdigit()} & set(plans)
        diag_reasons = {iid: {} for iid in diag_ids}
        diag_depth = {iid: {} for iid in diag_ids}
        def record_diag(iid, reason, placed_ids):
            if iid not in diag_ids:
                return
            reasons = diag_reasons[iid]
            reasons[reason] = reasons.get(reason, 0) + 1
            d = diag_depth[iid].setdefault(len(placed_ids), {})
            d[reason] = d.get(reason, 0) + 1
        diag39 = 39 in plans
        diag39_reasons = {}
        diag39_depth = {}
        def record39(reason, placed_ids):
            if not diag39:
                return
            reason = str(reason)
            diag39_reasons[reason] = diag39_reasons.get(reason, 0) + 1
            depth = len(placed_ids)
            ent = diag39_depth.setdefault(depth, {})
            ent[reason] = ent.get(reason, 0) + 1
        order_rank = {int(i): r for r, i in enumerate(graph.get('order', []))}
        all_ids = set(int(i) for i in plans)
        base_packed = {
            cidx: self._oriented_packed(c.get('packed_items', []) or [])
            for cidx, c in enumerate(containers)
        }

        def executable(iid, packed_by_container, placed_ids):
            plan = plans[int(iid)]
            cidx = int(plan['container_idx'])
            c = containers[cidx]
            execution_target, _ = self.insertion_planner.execution_target(plan)

            # Fixed shelves are permanent obstacles.
            if not self._static_shelf_path_clear(c, plan['item'], execution_target):
                record_diag(iid, 'fixed_shelf_path', placed_ids)
                if iid == 39: record39('fixed_shelf_path', placed_ids)
                return False

            # Support is physical: an upper box cannot be inserted before its
            # designated supporter.  Shelf/floor support is checked directly.
            if str(plan.get('support_kind', '')) == 'box':
                sid = plan.get('support_item_id')
                if sid is None or int(sid) not in placed_ids:
                    record_diag(iid, 'support_not_yet_placed', placed_ids)
                    if iid == 39: record39('support_not_yet_placed', placed_ids)
                    return False

            packed = packed_by_container[cidx]
            support_meta = self._runtime_support_check(plan, c, packed)
            if not bool(support_meta.get('ok', False)):
                record_diag(iid, 'support_invalid:'+str(support_meta.get('reason')), placed_ids)
                if iid == 39: record39('support_invalid:'+str(support_meta.get('reason')), placed_ids)
                return False

            # The real validator checks *all* previously placed cargo, including
            # the supporting box. Excluding it overestimates insertability.
            path_ok = bool(self._validator_aligned_runtime_path_clear(
                c, plan['item'], execution_target, packed))
            if iid in diag_ids:
                if path_ok:
                    record_diag(iid, 'READY', placed_ids)
                else:
                    blockers = []
                    issued = self._clamp_to_safe_margin(c, plan['item'], execution_target, int(plan['orientation']))
                    for obj in packed:
                        if obj.get('pos') is not None and not self._actual_simulator_entry_clear(c, plan['item'], issued, [obj], verbose=False):
                            blockers.append(int(obj.get('index', -1)))
                    record_diag(iid, 'blocked:'+','.join(map(str,sorted(blockers))) if blockers else 'path_other', placed_ids)
            if iid == 39:
                if path_ok:
                    record39('READY', placed_ids)
                else:
                    # Isolate which already-loaded cargo block the exact Y->X sweep.
                    blockers = []
                    issued = self._clamp_to_safe_margin(c, plan['item'], execution_target, int(plan['orientation']))
                    for obj in packed:
                        if obj.get('pos') is None:
                            continue
                        if not self._actual_simulator_entry_clear(c, plan['item'], issued, [obj], verbose=False):
                            blockers.append(int(obj.get('index', -1)))
                    record39('blocked:'+','.join(map(str,sorted(blockers))) if blockers else 'path_other', placed_ids)
            return path_ok

        def clone_packed(src):
            return {cidx: [dict(obj) for obj in objs] for cidx, objs in src.items()}

        # Each state is immutable enough for cheap branching.  Fixed final
        # records mean only the set/order matters; geometry itself never drifts.
        frontier = [{
            'placed': frozenset(),
            'order': (),
            'packed': base_packed,
            'rank_sum': 0,
        }]
        best = frontier[0]
        visited = {frozenset(): (0, ())}
        expanded_states = 0

        while frontier:
            children = []
            for state in frontier:
                expanded_states += 1
                placed = set(state['placed'])
                remaining = all_ids - placed
                ready = [
                    iid for iid in remaining
                    if executable(iid, state['packed'], placed)
                ]
                if not ready:
                    if len(placed) > len(best['placed']):
                        best = state
                    continue

                # Prefer the current precedence order, but branch over several
                # executable choices instead of treating that order as absolute.
                ready.sort(key=lambda iid: (
                    order_rank.get(iid, 10**9),
                    int(plans[iid].get('plan_rank', 10**9)), iid,
                ))
                for iid in ready[:self.feasibility_branch]:
                    new_placed = frozenset((*state['placed'], iid))
                    new_order = state['order'] + (iid,)
                    rank_sum = state['rank_sum'] + order_rank.get(iid, 10**6)
                    old = visited.get(new_placed)
                    if old is not None and old <= (rank_sum, new_order):
                        continue
                    visited[new_placed] = (rank_sum, new_order)
                    new_packed = clone_packed(state['packed'])
                    cidx = int(plans[iid]['container_idx'])
                    new_packed[cidx].append(dict(plans[iid]['packed_record']))
                    children.append({
                        'placed': new_placed,
                        'order': new_order,
                        'packed': new_packed,
                        'rank_sum': rank_sum,
                    })

            if not children:
                break

            for iid in sorted(diag_ids):
                count = sum(iid in st['placed'] for st in children)
                if count:
                    print(f'[V14-BRANCH] item={iid} depth={len(frontier[0]["placed"])} children_with_item={count} total_children={len(children)}', flush=True)
            if diag39:
                kept_before = sum(39 in x['placed'] for x in children)
                ready_at_depth = diag39_depth.get(len(frontier[0]['placed']), {}).get('READY', 0)
                if ready_at_depth or kept_before:
                    print(f'[ORDER39-BEAM] depth={len(frontier[0]["placed"])} ready_checks={ready_at_depth} children_with39={kept_before} total_children={len(children)}',flush=True)

            # At a common search depth every child has the same item count.
            # Lower precedence-rank sum is a stable tie-break, while larger
            # packed volume favors keeping high-value futures alive.
            def state_key(st):
                sub = {iid: plans[iid] for iid in st['placed']}
                m = self._layout_metrics(sub)
                return (m[0], -st['rank_sum'], tuple(-x for x in st['order']))

            children.sort(key=state_key, reverse=True)
            dedup = []
            seen = set()
            for st in children:
                sig = st['placed']
                if sig in seen:
                    continue
                seen.add(sig)
                dedup.append(st)
                if len(dedup) >= self.feasibility_beam:
                    break
            frontier = dedup
            for iid in sorted(diag_ids):
                retained = sum(iid in st['placed'] for st in frontier)
                if retained:
                    print(f'[V14-PRUNE] item={iid} depth={len(frontier[0]["placed"])} retained={retained} beam={len(frontier)}',flush=True)
            if diag39 and (diag39_depth.get(len(frontier[0]['placed'])-1,{}).get('READY',0) or any(39 in st['placed'] for st in frontier)):
                print(f'[ORDER39-PRUNE] depth={len(frontier[0]["placed"])} retained_with39={sum(39 in st["placed"] for st in frontier)} retained_total={len(frontier)}',flush=True)

            for st in frontier:
                if len(st['placed']) > len(best['placed']):
                    best = st

        for iid in sorted(diag_ids):
            print(f'[V14-SUMMARY] item={iid} geom=True safe={iid in best["placed"]} '
                  f'plan_rank={plans[iid].get("plan_rank")} '
                  f'order_rank={order_rank.get(iid)} '
                  f'support={plans[iid].get("support_kind")}:{plans[iid].get("support_item_id")} '
                  f'reasons={diag_reasons[iid]} by_depth={diag_depth[iid]}', flush=True)
        if diag39:
            print(f'[ORDER39-SUMMARY] geom39=True best_has39={39 in best["placed"]} best_count={len(best["placed"])} reasons={diag39_reasons} by_depth={diag39_depth}',flush=True)
            print(f'[ORDER39-GRAPH] support22_to39={39 in graph.get("edges",{}).get(22,set())} order39_rank={order_rank.get(39)} dropped_routes_for39={[p for p in graph.get("dropped_route_edges",[]) if 39 in p]}',flush=True)
        safe_ids = [int(i) for i in best['order']]
        safe_set = set(safe_ids)
        safe_plans = {iid: plans[iid] for iid in safe_ids}
        return {
            'safe_ids': safe_ids,
            'safe_order': safe_ids,
            'blocked_ids': sorted(all_ids - safe_set),
            'metrics': self._layout_metrics(safe_plans),
            'graph': graph,
            'beam_states': expanded_states,
        }

    def _selection_metrics(self, geometric_metrics, feasibility):
        """Objective used to choose among Multi-Start layouts.

        Safe insertable volume and count are primary.  Raw geometric packing is
        intentionally only a tie-break: a layout that packs 34 boxes but can
        safely execute 17 must lose to one that packs 32 and safely executes 30.
        """
        fm = feasibility['metrics']
        return (
            float(fm[0]), int(fm[1]),
            float(geometric_metrics[0]), int(geometric_metrics[1]),
            float(fm[2]), float(geometric_metrics[2]),
            float(fm[3]), float(geometric_metrics[3]),
        )

    def _layout_metrics(self, plans):
        """Lexicographic objective for selecting a Multi-Start layout.

        Primary objective is packed physical volume (the closest direct proxy for
        fill score), followed by item count, then lower mass-weighted CoG and
        lower accumulated local placement score.  The returned tuple is ordered
        so that larger is always better.
        """
        if not plans:
            return (0.0, 0, float('-inf'), float('-inf'))
        volume = 0.0
        mass_sum = 0.0
        mz = 0.0
        score_sum = 0.0
        for p in plans.values():
            it = p['item']
            volume += float(it['length']) * float(it['width']) * float(it['height'])
            m = float(it.get('mass', 0.0))
            mass_sum += m
            mz += m * float(p['final_target'][2])
            score_sum += float(p.get('score', 0.0))
        cog_z = mz / mass_sum if mass_sum > 1e-12 else 0.0
        return (float(volume), int(len(plans)), -float(cog_z), -float(score_sum))

    def _search_full_geometric_plan(self, item_list, containers, source='optimize'):
        """Run Multi-Start × geometric Beam and select by executable packing."""
        variants = self._search_order_variants(item_list)
        t0 = time.perf_counter()
        best_result = None
        best_feasibility = None
        best_name = None
        summaries = []
        evaluated_layouts = 0
        budget_stop = False

        for trial, (name, order) in enumerate(variants, start=1):
            elapsed = time.perf_counter() - t0
            if trial > 1 and elapsed >= self.search_max_seconds:
                print(
                    f'[search_cand_v5][SEARCH] budget-stop after={trial-1} '
                    f'layouts={evaluated_layouts} elapsed={elapsed:.3f}s',
                    flush=True,
                )
                break

            self.diag_trial = f'{trial}/{len(variants)}:{name}'
            result = self._build_layout_for_order(order, containers, source=source)
            beam_layouts = result.get('beam_layouts', [result])

            for beam_idx, layout in enumerate(beam_layouts, start=1):
                elapsed = time.perf_counter() - t0
                if evaluated_layouts > 0 and elapsed >= self.search_max_seconds:
                    budget_stop = True
                    break

                geometric = layout['metrics']
                feasibility = self._evaluate_insertion_feasibility(
                    layout['plans'], containers
                )
                safe_metrics = feasibility['metrics']
                select_metrics = self._selection_metrics(geometric, feasibility)
                evaluated_layouts += 1

                label = f'{name}/beam{beam_idx}'
                summaries.append({
                    'trial': trial,
                    'beam_idx': beam_idx,
                    'strategy': name,
                    'label': label,
                    'metrics': geometric,
                    'safe_metrics': safe_metrics,
                    'selection_metrics': select_metrics,
                    'placed': len(layout['plans']),
                    'safe_placed': len(feasibility['safe_ids']),
                    'blocked': feasibility['blocked_ids'],
                    'safe_order': feasibility['safe_order'],
                    'deferred': layout['deferred_final'],
                    'retry_rounds': layout['retry_rounds'],
                    'tested': layout['tested'],
                    'beam_states': feasibility['beam_states'],
                })
                print(
                    f'[search_cand_v5][SEARCH] trial={trial}/{len(variants)} '
                    f'beam={beam_idx}/{len(beam_layouts)} strategy={name} '
                    f'geom_placed={len(layout["plans"])} geom_volume={geometric[0]:.6f} '
                    f'safe_placed={len(feasibility["safe_ids"])} '
                    f'safe_volume={safe_metrics[0]:.6f} '
                    f'blocked={feasibility["blocked_ids"]} '
                    f'insert_beam_states={feasibility["beam_states"]} '
                    f'retries={layout["retry_rounds"]} '
                    f'deferred={layout["deferred_final"]}',
                    flush=True,
                )

                if (
                    best_result is None
                    or select_metrics > self._selection_metrics(
                        best_result['metrics'], best_feasibility
                    )
                ):
                    # Retain the v2/v3 safety rule: only the subset that the
                    # insertion feasibility search can actually order is sent to
                    # the simulator.  v4's improvement is finding a better
                    # geometric candidate before this safety gate, not bypassing it.
                    safe_ids = feasibility['safe_ids']
                    committed = dict(layout)
                    committed['geometric_plans'] = dict(layout['plans'])
                    committed['plans'] = {
                        iid: layout['plans'][iid] for iid in safe_ids
                    }
                    best_result = committed
                    best_feasibility = feasibility
                    best_name = label

            if budget_stop:
                print(
                    f'[search_cand_v5][SEARCH] budget-stop trial={trial} '
                    f'layouts={evaluated_layouts} '
                    f'elapsed={time.perf_counter()-t0:.3f}s',
                    flush=True,
                )
                break

        if best_result is None:
            best_result = {
                'plans': {},
                'metrics': (0.0, 0, float('-inf'), float('-inf')),
            }
            best_feasibility = {
                'metrics': best_result['metrics'],
                'safe_ids': [],
                'blocked_ids': [],
                'safe_order': [],
            }
            best_name = 'none'

        self.geometric_preplanned = dict(best_result.get('geometric_plans', best_result['plans']))
        for (trial_label, iid), stats in sorted(self.diag_stats.items()):
            print(f'[DIAG-SUMMARY] trial={trial_label} item={iid} stats={stats}', flush=True)
        self.preplanned = dict(best_result['plans'])
        self.feasibility_order = [
            int(iid) for iid in best_feasibility.get('safe_order', [])
            if int(iid) in self.preplanned
        ]
        self.plan_counter = len(self.preplanned)
        self.search_top_summary = sorted(
            summaries,
            key=lambda x: x['selection_metrics'],
            reverse=True,
        )[:5]

        elapsed = time.perf_counter() - t0
        gm = best_result['metrics']
        sm = best_feasibility['metrics']
        print(
            f'[search_cand_v5][SEARCH-BEST] strategy={best_name} '
            f'safe_placed={len(self.preplanned)} safe_volume={sm[0]:.6f} '
            f'geom_placed={gm[1]} geom_volume={gm[0]:.6f} '
            f'layouts={evaluated_layouts} elapsed={elapsed:.3f}s '
            f'blocked={best_feasibility.get("blocked_ids", [])} '
            f'top={[(x["label"], x["safe_placed"], round(x["safe_metrics"][0],6), x["placed"]) for x in self.search_top_summary]}',
            flush=True,
        )

    def _extend_geometric_plan(self, items, containers, source='rolling'):
        """Reserve non-overlapping fixed final targets using geometry only."""
        # Start from actual/current geometry and reserve every already planned
        # but unexecuted final pose. This prevents rolling replanning overlap.
        planned_packed = {}
        local_used = {}
        for cidx, c in enumerate(containers):
            if source == 'optimize':
                base = self._oriented_packed(c.get('packed_items', []) or [])
            else:
                base = self._effective_packed(cidx, c)
            base_ids = {int(o['index']) for o in base if o.get('index') is not None}
            reserved_added = 0
            for rec in self._reserved_plan_records(cidx):
                rid = rec.get('index')
                if rid is not None and int(rid) in base_ids:
                    continue
                base.append(rec)
                reserved_added += 1
                if rid is not None:
                    base_ids.add(int(rid))
            planned_packed[cidx] = base
            if source == 'rolling' and reserved_added:
                print(
                    f'[search_cand_v5][RESERVE] container={cidx} '
                    f'fixed_targets_added={reserved_added} occupied={len(base)}',
                    flush=True,
                )
            local_used[cidx] = set(self.used_ep_keys[cidx]) if cidx < len(self.used_ep_keys) else set()
            for p in self.preplanned.values():
                if int(p['container_idx']) == cidx:
                    local_used[cidx].add(self._ep_location_key(p['ep']))

        for raw_item in items:
            iid = int(raw_item['index'])
            if iid in self.preplanned:
                continue
            best = None
            tested = 0

            # v4: ordinary EPs have priority. Projected X-Y EPs are searched
            # only if no ordinary EP is feasible anywhere.
            for ep_phase in ('ordinary', 'projected'):
                phase_best = None
                for cidx, c in enumerate(containers):
                    packed = planned_packed[cidx]
                    eps_all = self._generate_extreme_points(c, packed)
                    eps = [ep for ep in eps_all if self._ep_location_key(ep) not in local_used[cidx]]
                    if ep_phase == 'ordinary':
                        eps = [ep for ep in eps if ':proj:' not in str(ep[3] if len(ep) >= 4 else '')]
                    else:
                        eps = [ep for ep in eps if ':proj:' in str(ep[3] if len(ep) >= 4 else '')]
                    for item in self._oriented_variants(raw_item):
                        for ep in eps:
                            tested += 1
                            cand = self._center_from_ep(ep, item)
                            if self._overlaps_preplanned_reservation(cidx, item, cand, ignore_item_id=iid):
                                continue
                            if not self._inside_container(c, item, cand):
                                continue
                            if self._intersects_shelf_plate(c, item, cand):
                                continue
                            support = self._support_info(c, item, cand, packed)
                            if not support['ok']:
                                continue
                            if not self._final_clear(c, item, cand, packed, support_obj=support.get('support_obj')):
                                continue

                            # Static shelves never move. Reject permanently
                            # unreachable targets at BPP time instead of letting
                            # InsertionPlanner discover them later. Shelf-support
                            # candidates use the same temporary execution lift.
                            static_target = tuple(float(v) for v in cand)
                            if support.get('kind') in ('small-shelf', 'main-shelf'):
                                static_target = (
                                    static_target[0], static_target[1],
                                    static_target[2] + self.insertion_planner.shelf_lift,
                                )
                            if not self._static_shelf_path_clear(c, item, static_target):
                                continue
                            if not self._bpp_required_support_path_clear(c, item, cand, support):
                                continue

                            score = self._score_candidate(c, raw_item, item, cand, ep, support, packed)
                            q = (score, cidx, cand, item, ep, support)
                            if phase_best is None or (score, int(item['_orientation']), cidx) < (
                                phase_best[0], int(phase_best[3]['_orientation']), phase_best[1]
                            ):
                                phase_best = q
                if phase_best is not None:
                    best = phase_best
                    break
            if best is None:
                print(
                    f'[search_cand_v5][PACK-PLAN] source={source} item={iid} NO-GEOMETRIC-CANDIDATE tested={tested}',
                    flush=True,
                )
                continue

            score, cidx, pos, item, ep, support = best
            ori = int(item['_orientation'])
            support_obj = support.get('support_obj')
            support_item_id = None
            if support_obj is not None and support_obj.get('index') is not None:
                support_item_id = int(support_obj['index'])

            rec = self._make_planned_packed_record(containers[cidx], item, pos, ori)
            plan = {
                'item_id': iid,
                'container_idx': int(cidx),
                'final_target': tuple(float(v) for v in pos),
                'orientation': ori,
                'item': dict(item),
                'ep': tuple(ep),
                'support_kind': support['kind'],
                'support_ratio': float(support['ratio']),
                'support_item_id': support_item_id,
                'score': float(score),
                'plan_rank': int(self.plan_counter),
                'packed_record': rec,
                'source': source,
            }
            self.plan_counter += 1
            self.preplanned[iid] = plan
            planned_packed[cidx].append(rec)
            local_used[cidx].add(self._ep_location_key(ep))
            print(
                f'[search_cand_v5][PACK-PLAN] source={source} rank={plan["plan_rank"]} item={iid} '
                f'ori={ori} final_target=({pos[0]:.3f},{pos[1]:.3f},{pos[2]:.3f}) '
                f'support={support["kind"]} support_item={support_item_id} score={score:.5f}',
                flush=True,
            )

    def _overlaps_preplanned_reservation(self, cidx, item, cand, ignore_item_id=None):
        """Return True when cand overlaps any already fixed BPP target.

        This is intentionally independent from packed_items/internal_packed.
        In rolling lookahead the simulator observation can lag action issuance,
        but a fixed final target must remain reserved from the moment it is
        planned until the episode ends.
        """
        x, y, z = map(float, cand)
        hx = float(item['length']) * 0.5
        hy = float(item['width']) * 0.5
        hz = float(item['height']) * 0.5
        for rid, plan in self.preplanned.items():
            if ignore_item_id is not None and int(rid) == int(ignore_item_id):
                continue
            if int(plan.get('container_idx', -1)) != int(cidx):
                continue
            other = plan['item']
            ox, oy, oz = map(float, plan['final_target'])
            ohx = float(other['length']) * 0.5
            ohy = float(other['width']) * 0.5
            ohz = float(other['height']) * 0.5
            if (
                abs(x - ox) < hx + ohx + self.xy_gap and
                abs(y - oy) < hy + ohy + self.xy_gap and
                abs(z - oz) < hz + ohz + self.z_gap
            ):
                return True
        return False

    def _make_planned_packed_record(self, c, item, local_pos, orientation):
        center = c.get('center', (0.0, 0.0, 0.0))
        rec = dict(item)
        # Simulator local_to_global() applies only the container X offset.
        rec['pos'] = (
            float(local_pos[0]) + float(center[0]),
            float(local_pos[1]),
            float(local_pos[2]),
        )
        rec['_orientation'] = int(orientation)
        rec['_already_oriented'] = True
        return rec

    def _rebuild_precedence(self, containers):
        pending = [p for iid, p in self.preplanned.items() if iid not in self.executed_ids]
        self.precedence_graph = self.insertion_planner.build_precedence(pending, containers)
        edges = []
        for a, dsts in self.precedence_graph.get('edges', {}).items():
            for b in sorted(dsts):
                rs = '+'.join(self.precedence_graph.get('reasons', {}).get((a, b), []))
                edges.append(f'{a}->{b}:{rs}')
        print(
            f'[search_cand_v5][INSERT-GRAPH] edges={edges} '
            f'order={self.precedence_graph.get("order", [])} '
            f'cycles={self.precedence_graph.get("cyclic", [])}',
            flush=True,
        )

    def _ep_location_key(self, ep):
        """Quantized spatial key for an EP, intentionally ignoring source label.

        Two EPs at the same physical location are considered the same consumable
        placement anchor even if they were generated from different sources.
        """
        q = max(float(self.ep_quant), 1e-9)
        return (
            int(round(float(ep[0]) / q)),
            int(round(float(ep[1]) / q)),
            int(round(float(ep[2]) / q)),
        )

    # ------------------------------------------------------------------
    # Orientation / packed geometry
    # ------------------------------------------------------------------
    def _orientation_dims(self, item, orientation):
        L = float(item['length'])
        W = float(item['width'])
        H = float(item['height'])
        return {
            0: (L, W, H),
            1: (L, H, W),
            2: (H, W, L),
            3: (W, L, H),
            4: (W, H, L),
            5: (H, L, W),
        }[int(orientation)]

    def _oriented_variants(self, item):
        out = []
        seen = set()
        for ori in range(6):
            L, W, H = self._orientation_dims(item, ori)
            key = (round(L, 6), round(W, 6), round(H, 6))
            if key in seen:
                continue
            seen.add(key)
            v = dict(item)
            v['length'], v['width'], v['height'] = L, W, H
            v['_orientation'] = ori
            out.append(v)
        # Low orientation first is only a deterministic enumeration order; the
        # final choice is made by the score function.
        out.sort(key=lambda v: (
            float(v['height']),
            -(float(v['length']) * float(v['width'])),
            int(v['_orientation']),
        ))
        return out

    def _oriented_packed(self, packed):
        out = []
        for obj in packed:
            v = dict(obj)
            idx = v.get('index')
            if bool(v.get('_already_oriented', False)):
                ori = int(v.get('_orientation', 0))
            else:
                ori = self.placed_orientation.get(int(idx), 0) if idx is not None else 0
                L, W, H = self._orientation_dims(v, ori)
                v['length'], v['width'], v['height'] = L, W, H
                v['_orientation'] = ori
            out.append(v)
        return out

    def _record_internal_placement(self, cidx, c, item, local_pos, orientation):
        while len(self.internal_packed) <= cidx:
            self.internal_packed.append([])

        center = c.get('center', (0.0, 0.0, 0.0))
        # Simulator local_to_global() applies only the container X offset.
        world_pos = (
            float(local_pos[0]) + float(center[0]),
            float(local_pos[1]),
            float(local_pos[2]),
        )
        rec = dict(item)
        rec['pos'] = world_pos
        rec['_orientation'] = int(orientation)
        rec['_already_oriented'] = True

        idx = rec.get('index')
        if idx is not None:
            idx = int(idx)
            self.internal_packed[cidx] = [
                p for p in self.internal_packed[cidx]
                if p.get('index') is None or int(p.get('index')) != idx
            ]
        self.internal_packed[cidx].append(rec)

    def _effective_packed(self, cidx, c):
        """Merge settled simulator poses with just-issued internal poses.

        Simulator entries win for matching item ids because they contain the
        actual PyBullet-settled pose.  Internal entries only bridge the one-step
        observation lag immediately after returning an action.
        """
        sim_raw = c.get('packed_items', []) or []
        sim_packed = self._oriented_packed(sim_raw)
        for obj in sim_packed:
            obj['_support_pose_source'] = 'settled'
        sim_ids = {
            int(o['index']) for o in sim_packed
            if o.get('index') is not None
        }

        internal = self.internal_packed[cidx] if cidx < len(self.internal_packed) else []
        merged = list(sim_packed)
        for obj in internal:
            idx = obj.get('index')
            if idx is not None and int(idx) in sim_ids:
                continue
            v = dict(obj)
            v['_support_pose_source'] = 'planned'
            merged.append(v)
        return merged

    # ------------------------------------------------------------------
    # Extreme Points
    # ------------------------------------------------------------------
    def _generate_extreme_points(self, c, packed):
        """Generate mirrored EPs: floor/shelf seeds + left/front/top of boxes.

        v01 intentionally keeps the generator compact.  A compact projected X-Y corner set is added for top-view pockets; more
        aggressive dominance pruning is intentionally still omitted.
        """
        L, W, H = float(c['length']), float(c['width']), float(c['height'])
        t = float(c.get('thickness', 0.04))
        xmax = L/2 - t - self.boundary_margin
        ymax = W/2 - t - self.boundary_margin
        floor_z = t + self.boundary_margin
        cut_x = float(c.get('cut_x', 0.0))

        # The left opening/cut_x region is not a usable floor-entry seed.
        # Start the left-back floor seed just to the right of that region.
        xmin_inner = -L/2 + t + cut_x + self.boundary_margin
        # Only one floor seed.  After the first placement, floor expansion must
        # continue from right:/front: EPs generated by already placed boxes.
        # Keeping an independent floor-right-seed caused large unused gaps.
        raw = [
            (xmin_inner, ymax, floor_z, 'floor-left-seed'),
        ]

        # Small shelf is always present in this simulator family.
        buffer = float(c.get('buffer', 0.0))
        if cut_x > 0.0:
            ss_xmax = -L/2 + t + cut_x
            ss_ymax = W/2 - t
            ss_top = H/2 + buffer + t
            raw.append((ss_xmax - self.boundary_margin, ss_ymax - self.boundary_margin, ss_top + self.z_gap, 'small-shelf-seed'))

        # Optional main shelf, back half.
        if bool(c.get('shelf', c.get('require_shelf', False))):
            ms_xmax = (L - t) / 2.0
            ms_ymax = W/2 - t
            ms_top = H/2 + buffer + t
            raw.append((ms_xmax - self.boundary_margin, ms_ymax - self.boundary_margin, ms_top + self.z_gap, 'main-shelf-seed'))

        # Every packed item contributes mirrored EPs.  Keep the individual
        # box EPs, and also remember its horizontal faces for a small projected
        # X-Y corner set below.  The latter is useful for top-view gaps that are
        # defined by the X face of one box and the Y face of another.
        face_records = []
        for obj in packed:
            if obj.get('pos') is None:
                continue
            ox, oy, oz = self._local_pos(c, obj['pos'])
            hx = float(obj['length']) / 2.0
            hy = float(obj['width']) / 2.0
            hz = float(obj['height']) / 2.0
            xmin, xmax_o = ox - hx, ox + hx
            ymin, ymax_o = oy - hy, oy + hy
            zmin, zmax_o = oz - hz, oz + hz
            oid = int(obj.get('index', -1))
            face_records.append((oid, xmin, xmax_o, ymin, ymax_o, zmin, zmax_o))

            # Lateral EPs on both sides. `right:*` stores the LEFT face of
            # the future candidate; `left:*` stores its RIGHT face.  These are
            # purely geometric packing anchors; insertion feasibility is handled
            # separately by InsertionPlanner.
            raw.append((xmin - self.ep_gap, ymax_o, zmin, f'left:{oid}'))
            raw.append((xmax_o + self.ep_gap, ymax_o, zmin, f'right:{oid}'))
            raw.append((xmax_o, ymin - self.ep_gap, zmin, f'front:{oid}'))
            raw.append((xmax_o, ymax_o, zmax_o + self.z_gap, f'top:{oid}'))

        # Projected top-view EPs (small O(n^2) set).
        #
        # Current EPs derive X and Y from the same box.  In a top view this can
        # miss a rectangular pocket whose left/right boundary is box A while
        # its back/front boundary is box B.  Combine an X side face from A with
        # the front face of B when both bottoms are on approximately the same
        # support level.  Normal inclusion/support/final-clear filters still
        # decide whether the projected point is actually usable.
        layer_tol = max(self.support_z_tolerance, 0.04)
        for a in face_records:
            aid, axmin, axmax, aymin, aymax, azmin, _ = a
            for b in face_records:
                bid, bxmin, bxmax, bymin, bymax, bzmin, _ = b
                if aid == bid or abs(azmin - bzmin) > layer_tol:
                    continue
                zbase = max(azmin, bzmin)
                # Candidate immediately to +X of A and in front of B.
                raw.append((
                    axmax + self.ep_gap,
                    bymin - self.ep_gap,
                    zbase,
                    f'right:proj:{aid}:{bid}',
                ))
                # Symmetric candidate immediately to -X of A and in front of B.
                raw.append((
                    axmin - self.ep_gap,
                    bymin - self.ep_gap,
                    zbase,
                    f'left:proj:{aid}:{bid}',
                ))

        # Quantized de-duplication.  Prefer lower z, then deeper y, then right x.
        dedup = {}
        for x, y, z, source in raw:
            key = (
                int(round(x / self.ep_quant)),
                int(round(y / self.ep_quant)),
                int(round(z / self.ep_quant)),
            )
            old = dedup.get(key)
            ep = (float(x), float(y), float(z), source)
            if old is None or (z, -y, -x) < (old[2], -old[1], -old[0]):
                dedup[key] = ep

        eps = list(dedup.values())
        eps.sort(key=lambda e: (e[2], -e[1], -e[0], e[3]))
        eps = eps[:self.max_eps_per_container]
        return eps

    def _center_from_ep(self, ep, item):
        x_edge, y_edge, z_bottom = ep[:3]
        source = ep[3] if len(ep) >= 4 else ''
        # Most EPs store the candidate's +X face.  The special left-seed and
        # right-expansion EPs store the candidate's -X face instead.
        if source == 'floor-left-seed' or source.startswith('right:'):
            cx = float(x_edge) + float(item['length']) / 2.0
        else:
            cx = float(x_edge) - float(item['length']) / 2.0
        return (
            cx,
            float(y_edge) - float(item['width']) / 2.0,
            float(z_bottom) + float(item['height']) / 2.0,
        )

    # ------------------------------------------------------------------
    # Feasibility
    # ------------------------------------------------------------------
    def _inside_container(self, c, item, cand):
        """Exact replica of PlacementValidator.check_inclusion().

        `cand` is the local action coordinate used by the agent.  The simulator
        stores container.points in world coordinates, while local_to_global()
        only adds the container X offset.  Therefore convert only X before
        evaluating the validator plane equations.

        Validator formula:
          dot(n, target-point) + dot(abs(n), half_lwh) <= inclusion_margin
        """
        n_vecs = c.get('n_vecs')
        points = c.get('points')
        if n_vecs is None or points is None:
            # Defensive fallback for non-simulator unit tests.
            L, W, H = float(c['length']), float(c['width']), float(c['height'])
            t = float(c.get('thickness', 0.04))
            x, y, z = map(float, cand)
            hx = float(item['length']) / 2.0
            hy = float(item['width']) / 2.0
            hz = float(item['height']) / 2.0
            m = self.boundary_margin
            return (
                x - hx >= -L/2 + t + m and
                x + hx <=  L/2 - t - m and
                y - hy >= -W/2 + t + m and
                y + hy <=  W/2 - t - m and
                z - hz >= t and
                z + hz <= H - t - 0.01
            )

        n = np.asarray(n_vecs, dtype=np.float64)
        p = np.asarray(points, dtype=np.float64)
        x, y, z = map(float, cand)
        # Container.local_to_global(local_pos) == (local_x + offset_x, y, z).
        # c['center'][0] equals offset_x for this simulator.
        offset_x = float(c.get('center', (0.0, 0.0, 0.0))[0])
        target_world = np.asarray((x + offset_x, y, z), dtype=np.float64)
        half_lwh = np.asarray((
            float(item['length']) / 2.0,
            float(item['width']) / 2.0,
            float(item['height']) / 2.0,
        ), dtype=np.float64)

        dots = (n * (target_world - p)).sum(axis=1) + np.dot(np.abs(n), half_lwh)
        ok = bool(np.all(dots <= float(self.inclusion_margin)))
        if not ok and os.environ.get('EP_DEBUG_INSIDE', '0') == '1':
            worst = int(np.argmax(dots))
            print(
                f'[search_cand_v5][INSIDE-REJECT] plane={worst} '
                f'dot={float(dots[worst]):.6f} limit={self.inclusion_margin:.6f} '
                f'target_local=({x:.3f},{y:.3f},{z:.3f})',
                flush=True,
            )
        return ok

    def _clamp_to_safe_margin(self, c, item, pos, orientation):
        """Nudge the target coordinate inward if it's too close to the container walls.

        This prevents 'not inside' rejects caused by floating point drift or
        minimal boundary violations.
        """
        act_l, act_w, act_h = (float(item[k]) for k in ('length', 'width', 'height'))  # plan.item is already oriented
        L, W, H = float(c['length']), float(c['width']), float(c['height'])
        t = float(c.get('thickness', 0.04))
        hx, hy, hz = act_l / 2.0, act_w / 2.0, act_h / 2.0

        # Safe nudge margin (5mm)
        margin = 0.005
        x, y, z = pos

        x_min, x_max = -L/2 + t + hx + margin, L/2 - t - hx - margin
        y_min, y_max = -W/2 + t + hy + margin, W/2 - t - hy - margin
        z_min, z_max = t + hz + margin, H - t - hz - margin

        cx = max(x_min, min(x, x_max)) if x_max > x_min else x
        cy = max(y_min, min(y, y_max)) if y_max > y_min else y
        cz = max(z_min, min(z, z_max)) if z_max > z_min else z

        return (cx, cy, cz)

    def _support_info(self, c, item, cand, packed):
        """Require floor, shelf, or one-box support for every candidate."""
        x, y, z = map(float, cand)
        hx = float(item['length'])/2.0
        hy = float(item['width'])/2.0
        hz = float(item['height'])/2.0
        bottom = z - hz
        footprint = max(1e-12, 4.0 * hx * hy)

        L, W, H = float(c['length']), float(c['width']), float(c['height'])
        t = float(c.get('thickness', 0.04))
        buffer = float(c.get('buffer', 0.0))

        if abs(bottom - t) <= self.support_z_tolerance:
            return {'ok': True, 'kind': 'floor', 'ratio': 1.0, 'support_obj': None}

        # Small shelf support: narrow X strip, almost full Y depth.
        cut_x = float(c.get('cut_x', 0.0))
        shelf_top = H/2 + buffer + t
        if cut_x > 0 and abs(bottom - shelf_top) <= self.support_z_tolerance:
            sx0 = -L/2 + t
            sx1 = sx0 + cut_x
            sy0 = -W/2 + t
            sy1 = W/2 - t
            ratio = self._rect_overlap_ratio(x-hx, x+hx, y-hy, y+hy, sx0, sx1, sy0, sy1)
            # Outer wall side cannot overhang; retain a small inward clearance.
            outer_ok = (x-hx) >= sx0 + self.boundary_margin
            if outer_ok and ratio >= self.min_support_ratio:
                return {'ok': True, 'kind': 'small-shelf', 'ratio': ratio, 'support_obj': None}

        # Main shelf support: back half.
        if bool(c.get('shelf', c.get('require_shelf', False))) and abs(bottom - shelf_top) <= self.support_z_tolerance:
            ms_lx = L - t
            ms_ly = W/2 - 2*t
            sx0, sx1 = -ms_lx/2, ms_lx/2
            cy = W/4
            sy0, sy1 = cy - ms_ly/2, cy + ms_ly/2
            ratio = self._rect_overlap_ratio(x-hx, x+hx, y-hy, y+hy, sx0, sx1, sy0, sy1)
            if ratio >= self.min_support_ratio:
                return {'ok': True, 'kind': 'main-shelf', 'ratio': ratio, 'support_obj': None}

        # Single-box support.  v01 intentionally avoids multi-support unions.
        upper_mass = float(item.get('mass', 0.0))
        best = None
        for obj in packed:
            if obj.get('pos') is None:
                continue
            ox, oy, oz = self._local_pos(c, obj['pos'])
            ohx = float(obj['length'])/2.0
            ohy = float(obj['width'])/2.0
            ohz = float(obj['height'])/2.0
            top = oz + ohz
            if abs(bottom - top) > self.support_z_tolerance:
                continue
            ratio = self._rect_overlap_ratio(
                x-hx, x+hx, y-hy, y+hy,
                ox-ohx, ox+ohx, oy-ohy, oy+ohy,
            )
            if ratio < self.min_support_ratio:
                continue
            support_mass = float(obj.get('mass', 0.0))
            if upper_mass > 0 and support_mass > 0 and upper_mass > support_mass + self.weight_tolerance:
                continue
            if bool(obj.get('is_soft', False)) and not bool(item.get('is_soft', False)):
                continue
            rank = (-ratio, top)
            if best is None or rank < best[0]:
                best = (rank, obj, ratio)
        if best is not None:
            return {'ok': True, 'kind': 'box', 'ratio': best[2], 'support_obj': best[1]}

        return {'ok': False, 'kind': 'none', 'ratio': 0.0, 'support_obj': None}

    @staticmethod
    def _rect_overlap_ratio(ax0, ax1, ay0, ay1, bx0, bx1, by0, by1):
        ox = max(0.0, min(ax1, bx1) - max(ax0, bx0))
        oy = max(0.0, min(ay1, by1) - max(ay0, by0))
        area = max(1e-12, (ax1-ax0) * (ay1-ay0))
        return (ox * oy) / area

    def _runtime_support_check(self, plan, c, packed):
        """Re-check the BPP support contract before selecting an insertion.

        For box support, use the current packed pose for the exact supporter
        when available. Simulator-settled poses are preferred; during the
        get_init_states lookahead phase an earlier BPP reservation may be the
        only pose available, which is reported as source='planned'.
        """
        kind = str(plan.get('support_kind', 'none'))
        item = plan['item']
        x, y, z = map(float, plan['final_target'])
        hx = float(item['length']) / 2.0
        hy = float(item['width']) / 2.0
        hz = float(item['height']) / 2.0
        bottom = z - hz

        L, W, H = float(c['length']), float(c['width']), float(c['height'])
        t = float(c.get('thickness', 0.04))
        buffer = float(c.get('buffer', 0.0))
        shelf_top = H/2 + buffer + t

        if kind == 'floor':
            ok = abs(bottom - t) <= self.support_z_tolerance
            return {'ok': ok, 'kind': kind, 'ratio': 1.0 if ok else 0.0, 'source': 'static', 'reason': 'floor'}

        if kind == 'small-shelf':
            cut_x = float(c.get('cut_x', 0.0))
            if cut_x <= 0 or abs(bottom - shelf_top) > self.support_z_tolerance:
                return {'ok': False, 'kind': kind, 'ratio': 0.0, 'source': 'static', 'reason': 'shelf-z'}
            sx0 = -L/2 + t
            sx1 = sx0 + cut_x
            sy0 = -W/2 + t
            sy1 = W/2 - t
            ratio = self._rect_overlap_ratio(x-hx, x+hx, y-hy, y+hy, sx0, sx1, sy0, sy1)
            outer_ok = (x-hx) >= sx0 + self.boundary_margin
            ok = outer_ok and ratio >= self.min_support_ratio
            return {'ok': ok, 'kind': kind, 'ratio': float(ratio), 'source': 'static', 'reason': 'small-shelf'}

        if kind == 'main-shelf':
            if not bool(c.get('shelf', c.get('require_shelf', False))) or abs(bottom - shelf_top) > self.support_z_tolerance:
                return {'ok': False, 'kind': kind, 'ratio': 0.0, 'source': 'static', 'reason': 'shelf-z'}
            ms_lx = L - t
            ms_ly = W/2 - 2*t
            sx0, sx1 = -ms_lx/2, ms_lx/2
            cy = W/4
            sy0, sy1 = cy - ms_ly/2, cy + ms_ly/2
            ratio = self._rect_overlap_ratio(x-hx, x+hx, y-hy, y+hy, sx0, sx1, sy0, sy1)
            ok = ratio >= self.min_support_ratio
            return {'ok': ok, 'kind': kind, 'ratio': float(ratio), 'source': 'static', 'reason': 'main-shelf'}

        if kind == 'box':
            support_id = plan.get('support_item_id')
            if support_id is None:
                return {'ok': False, 'kind': kind, 'ratio': 0.0, 'source': 'none', 'reason': 'missing-support-id'}
            support = None
            for obj in packed:
                if obj.get('index') is not None and int(obj['index']) == int(support_id):
                    support = obj
                    break
            if support is None or support.get('pos') is None:
                # get_init_states may issue several actions before PyBullet has
                # physically settled any of them.  A supporter whose action was
                # already issued is therefore a valid predecessor-plan support.
                if int(support_id) in self.executed_ids:
                    sp = self.preplanned.get(int(support_id))
                    if sp is not None and sp.get('packed_record') is not None:
                        support = dict(sp['packed_record'])
                        support['_support_pose_source'] = 'predecessor-plan'
                if support is None or support.get('pos') is None:
                    return {'ok': False, 'kind': kind, 'ratio': 0.0, 'source': 'none', 'reason': f'support-{support_id}-not-present'}
            elif support.get('_support_pose_source') == 'planned' and int(support_id) in self.executed_ids:
                # Make the semantics explicit in logs: this is not merely a
                # speculative reservation; its action is already ahead of the
                # current item in the issued action sequence.
                support = dict(support)
                support['_support_pose_source'] = 'predecessor-plan'

            ox, oy, oz = self._local_pos(c, support['pos'])
            ohx = float(support['length']) / 2.0
            ohy = float(support['width']) / 2.0
            ohz = float(support['height']) / 2.0
            top = oz + ohz
            if abs(bottom - top) > self.support_z_tolerance:
                return {
                    'ok': False, 'kind': kind, 'ratio': 0.0,
                    'source': support.get('_support_pose_source', 'unknown'),
                    'reason': f'z-gap={abs(bottom-top):.4f}',
                    'support_item': int(support_id),
                }
            ratio = self._rect_overlap_ratio(
                x-hx, x+hx, y-hy, y+hy,
                ox-ohx, ox+ohx, oy-ohy, oy+ohy,
            )
            ok = ratio >= self.min_support_ratio
            return {
                'ok': ok, 'kind': kind, 'ratio': float(ratio),
                'source': support.get('_support_pose_source', 'unknown'),
                'reason': 'box-footprint', 'support_item': int(support_id),
            }

        return {'ok': False, 'kind': kind, 'ratio': 0.0, 'source': 'none', 'reason': 'unknown-support-kind'}

    def _intersects_shelf_plate(self, c, item, cand):
        """Reject final poses crossing through shelf plates themselves."""
        x, y, z = map(float, cand)
        hx, hy, hz = float(item['length'])/2, float(item['width'])/2, float(item['height'])/2
        L, W, H = float(c['length']), float(c['width']), float(c['height'])
        t = float(c.get('thickness', 0.04))
        buffer = float(c.get('buffer', 0.0))
        shelf_cz = H/2 + buffer + t/2

        def overlap_box(cx, cy, cz, lx, ly, lz):
            return (
                abs(x-cx) < hx + lx/2 and
                abs(y-cy) < hy + ly/2 and
                abs(z-cz) < hz + lz/2 - 1e-9
            )

        cut_x = float(c.get('cut_x', 0.0))
        if cut_x > 0:
            cx = -L/2 + t + cut_x/2
            if overlap_box(cx, 0.0, shelf_cz, cut_x, W-2*t, t):
                return True

        if bool(c.get('shelf', c.get('require_shelf', False))):
            if overlap_box(0.0, W/4, shelf_cz, L-t, W/2-2*t, t):
                return True
        return False

    # ------------------------------------------------------------------
    # Candidate scoring
    # ------------------------------------------------------------------
    def _score_candidate(self, c, raw_item, item, cand, ep, support, packed):
        """Lower is better.  v01 uses only transparent hand-tuned terms."""
        L, W, H = float(c['length']), float(c['width']), float(c['height'])
        x, y, z = map(float, cand)
        mass = float(raw_item.get('mass', 0.0))
        max_mass = self.global_max_mass if self.global_max_mass not in (None, 0.0) else max(mass, 1.0)

        # Normalize to approximately [0,1].
        height_n = z / max(H, 1e-9)
        front_n = (W/2 - y) / max(W, 1e-9)      # 0 at back, 1 at front
        left_n = (L/2 - x) / max(L, 1e-9)       # 0 at right, 1 at left
        mass_n = mass / max(max_mass, 1e-9)

        # Geometric compactness only.  Transport lanes and insertion order are
        # deliberately handled by InsertionPlanner, not by the BPP score.

        # Heavy cargo is more strongly rewarded for low Z.
        cog_term = height_n * (1.0 + 1.5 * mass_n)

        support_bonus = support['ratio']
        soft_penalty = 0.35 if bool(raw_item.get('is_soft', False)) and support['kind'] != 'box' else 0.0

        score = (
            3.0 * cog_term +
            2.5 * front_n +
            0.25 * left_n -
            1.5 * support_bonus +
            soft_penalty
        )

        # v8: penalize filling a forward (entrance-side) slot while the SAME
        # X lane still has empty space behind it. This is a preference, not a
        # hard rejection: the exact insertion feasibility checker still decides
        # whether a complete candidate layout can actually be loaded.
        # Look only at *existing* packed items, not hypothetical future cargo.
        if self.rear_open_penalty > 0.0 and W > 1e-9:
            half_w = float(item['width']) * 0.5
            half_l = float(item['length']) * 0.5
            rear_edge = W/2 - float(c.get('thickness', 0.04))
            nearest_rear_face = rear_edge
            for obj in packed:
                if obj.get('pos') is None:
                    continue
                ox, oy, oz = self._local_pos(c, obj['pos'])
                overlap_x = max(0.0, min(x + half_l, ox + float(obj['length'])/2) -
                                       max(x - half_l, ox - float(obj['length'])/2))
                # An object in a distant X lane must not count as filling this lane.
                if overlap_x < min(2*half_l, float(obj['length'])) * self.rear_lane_overlap:
                    continue
                # Consider only boxes close to the candidate's height band.
                if abs(oz-z) >= (float(obj['height']) + float(item['height']))/2:
                    continue
                rear_obj_face = oy - float(obj['width'])/2
                if rear_obj_face >= y + half_w - 1e-6:
                    nearest_rear_face = min(nearest_rear_face, rear_obj_face)
            free_rear = max(0.0, nearest_rear_face - (y + half_w))
            score += self.rear_open_penalty * (free_rear / W) * front_n
        return float(score)

    # ------------------------------------------------------------------
    # C++ checker integration
    # ------------------------------------------------------------------
    def _load_cpp_checker(self, module_path):
        if self.cpp_mode == 'off':
            raise RuntimeError('Submission requires the bundled C++ checker (EP_CPP_MODE=cpp).')
        import importlib.util
        import sysconfig
        directory = Path(__file__).resolve().parent / 'checker'
        binary = directory / ('cpp_aabb_checker' + sysconfig.get_config_var('EXT_SUFFIX'))
        if not binary.is_file():
            raise RuntimeError(
                f'Bundled checker is missing for Python {sysconfig.get_python_version()}: '
                f'{binary.name}. Submission requires Linux x86_64 CPython 3.12.')
        spec = importlib.util.spec_from_file_location('cpp_aabb_checker', binary)
        checker = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(checker)
        if not hasattr(checker, 'aabb_overlap_python_order'):
            raise RuntimeError('Bundled checker lacks v05 API')
        self.cpp_checker = checker
        self.cpp_checker_path = str(directory)
        print(f'[submission][cpp] loaded {binary}', flush=True)

    def _cpp_box(self, item, pos=(0.0, 0.0, 0.0), box_id=None):
        b = self.cpp_checker.Box()
        idx = item.get('index', -1) if box_id is None else box_id
        b.id = int(-1 if idx is None else idx)
        b.cx, b.cy, b.cz = map(float, pos)
        b.lx = float(item['length'])
        b.ly = float(item['width'])
        b.lz = float(item['height'])
        b.mass = float(item.get('mass', 0.0))
        b.is_soft = bool(item.get('is_soft', False))
        return b

    def _cpp_container_bounds(self, c):
        L, W, H = float(c['length']), float(c['width']), float(c['height'])
        t = float(c.get('thickness', 0.04))
        return self.cpp_checker.ContainerBounds(
            -L/2 + t, L/2 - t,
            -W/2 + t, W/2 - t,
            t, H - t,
        )

    def _cpp_packed_boxes(self, c, packed, skip_obj=None):
        boxes = []
        for obj in packed:
            if obj.get('pos') is None or (skip_obj is not None and obj is skip_obj):
                continue
            boxes.append(self._cpp_box(obj, self._local_pos(c, obj['pos'])))
        return boxes

    def _final_clear(self, c, item, cand, packed, support_obj=None):
        if self.cpp_checker is not None and self.cpp_mode != 'off':
            moving = self._cpp_box(item, cand)
            fn = self.cpp_checker.aabb_overlap_python_order
            for other in self._cpp_packed_boxes(c, packed, skip_obj=support_obj):
                if bool(fn(moving, other, float(self.xy_gap), float(self.z_gap))):
                    self.cpp_stats['final_cpp'] += 1
                    return False
            self.cpp_stats['final_cpp'] += 1
            return True

        self.cpp_stats['python_fallback_final'] += 1
        x, y, z = map(float, cand)
        hx, hy, hz = float(item['length'])/2, float(item['width'])/2, float(item['height'])/2
        for obj in packed:
            if obj.get('pos') is None or (support_obj is not None and obj is support_obj):
                continue
            ox, oy, oz = self._local_pos(c, obj['pos'])
            ohx, ohy, ohz = float(obj['length'])/2, float(obj['width'])/2, float(obj['height'])/2
            if (
                abs(x-ox) < hx+ohx+self.xy_gap and
                abs(y-oy) < hy+ohy+self.xy_gap and
                abs(z-oz) < hz+ohz+self.z_gap
            ):
                return False
        return True


    def _bpp_required_support_path_clear(self, c, item, target, support):
        """Reject BPP poses whose *required supporter* blocks the Y->X approach.

        Other packed boxes are deliberately NOT checked here: they may be
        inserted later by InsertionPlanner. The support box, however, MUST
        exist before this item, so its blockage is independent of ordering.

        Use the same execution-target lift and simulator-aligned approach as
        insertion feasibility and runtime. No geometry or scoring is modified.
        """
        if os.environ.get('SC_BPP_SUPPORT_PATH_GATE', '1') == '0':
            return True
        if support.get('kind') != 'box':
            return True
        supporter = support.get('support_obj')
        if supporter is None or supporter.get('pos') is None:
            return False
        plan = {
            'item_id': int(item['index']),
            'final_target': tuple(float(v) for v in target),
            'support_kind': 'box',
        }
        execution_target, _ = self.insertion_planner.execution_target(plan)
        ori = int(item.get('_orientation', 0))
        issued = self._clamp_to_safe_margin(c, item, execution_target, ori)
        # Includes simulator's zero-lift near nominal shelf planes and its
        # ceiling/start-margin clamp. A placement may be geometrically valid
        # yet impossible to approach above its mandatory supporter.
        ok = self._actual_simulator_entry_clear(
            c, item, issued, [supporter], verbose=False
        )
        if not ok and int(item.get('index', -1)) in self.diagnostic_item_ids:
            print(
                f'[V13-SUPPORT-PATH-REJECT] item={item["index"]} '
                f'support={supporter.get("index")} '
                f'final_z={float(target[2]):.3f} issued_z={issued[2]:.3f} '
                f'orientation={ori}', flush=True,
            )
        return ok

    def _static_shelf_path_clear(self, c, item, target):
        """Check the simulator's fixed shelf plates along the Y->X insertion path.

        This deliberately does *not* change the BPP final target or insertion
        ordering.  It only closes a gap in runtime path validation: the C++
        checker can report the packed-item path clear while the moving item
        still clips a fixed shelf plate.
        """
        tx, ty, tz = map(float, target)
        L, W, H = float(c['length']), float(c['width']), float(c['height'])
        t = float(c.get('thickness', 0.04))
        cut_x = float(c.get('cut_x', 0.0))
        buffer = float(c.get('buffer', 0.0))
        hx = float(item['length']) / 2.0
        hy = float(item['width']) / 2.0
        hz = float(item['height']) / 2.0

        # Match the simulator/safe-grid transport convention: enter at the
        # clipped X, move in Y first, then laterally in X.  Elevated targets
        # are transported with the 8 cm approach lift.
        edge = max(self.start_margin, self.safety_margin + 0.003)
        x_min = -L/2 + t + cut_x + hx + edge
        x_max =  L/2 - t - hx - edge
        start_x = min(max(tx, x_min), x_max)
        start_y = -W / 2.0

        floor_bottom = tz - hz
        path_z = tz if 0.0 <= floor_bottom - t <= 0.05 else min(
            tz + 0.08,
            H - t - hz - self.start_margin,
        )

        shelf_cz = H/2 + buffer + t/2
        shelves = []
        if cut_x > 0.0:
            shelves.append((
                -L/2 + t + cut_x/2, 0.0, shelf_cz,
                cut_x, W - 2*t, t, 'small-shelf'
            ))
        if bool(c.get('shelf', c.get('require_shelf', False))):
            shelves.append((
                0.0, W/4, shelf_cz,
                L - t, W/2 - 2*t, t, 'main-shelf'
            ))

        def interval_overlap(a0, a1, b0, b1):
            return max(a0, b0) < min(a1, b1) - 1e-9

        for cx, cy, cz, lx, ly, lz, name in shelves:
            if abs(path_z - cz) >= hz + lz/2 - 1e-9:
                continue

            sx0, sx1 = cx - lx/2, cx + lx/2
            sy0, sy1 = cy - ly/2, cy + ly/2

            # Segment 1: fixed X=start_x, sweep Y from entrance to target Y.
            y0 = min(start_y, ty) - hy
            y1 = max(start_y, ty) + hy
            if (start_x + hx > sx0 + 1e-9 and
                    start_x - hx < sx1 - 1e-9 and
                    interval_overlap(y0, y1, sy0, sy1)):
                if os.environ.get('EP_DEBUG_SHELF_PATH', '0') == '1':
                    print(
                        f'[search_cand_v5][SHELF-PATH-REJECT] shelf={name} seg=Y '
                        f'target=({tx:.3f},{ty:.3f},{tz:.3f}) path_z={path_z:.3f}',
                        flush=True,
                    )
                return False

            # Segment 2: fixed Y=target Y, sweep X from start X to target X.
            x0 = min(start_x, tx) - hx
            x1 = max(start_x, tx) + hx
            if (ty + hy > sy0 + 1e-9 and
                    ty - hy < sy1 - 1e-9 and
                    interval_overlap(x0, x1, sx0, sx1)):
                if os.environ.get('EP_DEBUG_SHELF_PATH', '0') == '1':
                    print(
                        f'[search_cand_v5][SHELF-PATH-REJECT] shelf={name} seg=X '
                        f'target=({tx:.3f},{ty:.3f},{tz:.3f}) path_z={path_z:.3f}',
                        flush=True,
                    )
                return False

        return True

    def _actual_simulator_entry_clear(self, c, item, target, packed, verbose=True):
        """Guard the *issued* pose against the real validator Y -> X approach.

        A collision on the horizontal sweep can terminate the entire case even
        though the geometric final pose is valid. Use all prior observed/issued
        cargo, including support objects, and match the simulator's X clipping
        and start-Z logic. This is an analytical conservative precheck; PyBullet
        remains the authority.
        """
        tx, ty, tz = map(float, target)
        L, W, H = (float(c[k]) for k in ('length', 'width', 'height'))
        t = float(c.get('thickness', 0.04))
        buf = float(c.get('buffer', 0.0))
        hx = float(item['length']) / 2
        hy = float(item['width']) / 2
        hz = float(item['height']) / 2
        sm = float(self.start_margin)
        # PlacementValidator.check_transport_path uses start_margin, not safety.
        xmin = -L/2 + t + float(c.get('cut_x', 0)) + hx + sm
        xmax = L/2 - t - hx - sm
        sx = min(max(tx, xmin), xmax)
        sy = -W/2
        # Default start_z from simulator config (sample_config uses 0.08).
        lift = float(os.environ.get('EP_SIM_START_Z', '0.08'))
        floor_bottom = tz - hz
        shelves = (t, H/2 + t + buf)
        if any(0 <= floor_bottom - surface <= .05 for surface in shelves):
            lift = 0.0
        if lift > 0:
            for ceiling in (H/2 + buf, H + buf - t):
                clearance = ceiling - (tz + hz)
                if 0 <= clearance < lift + float(os.environ.get('EP_SIM_CEILING_MARGIN', '.01')):
                    lift = max(0, clearance - float(os.environ.get('EP_SIM_CEILING_MARGIN', '.01')) - .0005)
                    break
        sz = min(H + buf - t - hz - sm, tz + lift)
        margin = self.safety_margin
        for obj in packed:
            if obj.get('pos') is None or obj.get('index') == item.get('index'):
                continue
            ox, oy, oz = self._local_pos(c, obj['pos'])
            ohx = float(obj['length'])/2
            ohy = float(obj['width'])/2
            ohz = float(obj['height'])/2
            if abs(sz - oz) >= hz + ohz + margin:
                continue
            # Simulator performs Y movement at fixed X, followed by X movement
            # at fixed target Y. Include moving box extents at both segments.
            ylo, yhi = sorted((sy, ty))
            xlo, xhi = sorted((sx, tx))
            block_y = (abs(sx-ox) < hx+ohx+margin and
                       ylo-hy < oy+ohy+margin and yhi+hy > oy-ohy-margin)
            block_x = (abs(ty-oy) < hy+ohy+margin and
                       xlo-hx < ox+ohx+margin and xhi+hx > ox-ohx-margin)
            if block_y or block_x:
                if verbose:
                    print(
                    f'[search_cand_v6][ENTRY-BLOCK] moving={item.get("index")} '
                    f'obstacle={obj.get("index")} segment={"Y" if block_y else "X"} '
                    f'start=({sx:.3f},{sy:.3f},{sz:.3f}) '
                    f'target=({tx:.3f},{ty:.3f},{tz:.3f}) '
                    f'obstacle_pos=({ox:.3f},{oy:.3f},{oz:.3f})', flush=True)
                return False
        return True

    def _validator_aligned_runtime_path_clear(self, c, item, target, packed):
        """Use the same issued-pose and Y->X path gate at planning and runtime."""
        ori = int(item.get('_orientation', 0))
        issued = self._clamp_to_safe_margin(c, item, target, ori)
        return (self._inside_container(c, item, issued) and
                self._static_shelf_path_clear(c, item, issued) and
                self._actual_simulator_entry_clear(c, item, issued, packed, verbose=False))

    def _simulator_transport_packed_clear(self, c, item, target, packed):
        """Conservative packed-item check matching simulator motion order.

        The simulator first carries a box horizontally near the floor and only
        then raises it at the target XY.  Earlier C++ checks used the final/high
        target Z for the horizontal sweep, which missed blockers such as case000
        item21 blocking the insertion of upper item33.

        Model three segments:
          1) Y sweep at entry_z
          2) X sweep at entry_z
          3) vertical sweep at final (x,y) from entry_z to target_z
        """
        tx, ty, tz = map(float, target)
        L, W = float(c['length']), float(c['width'])
        t = float(c.get('thickness', 0.04))
        cut_x = float(c.get('cut_x', 0.0))
        hx = float(item['length']) * 0.5
        hy = float(item['width']) * 0.5
        hz = float(item['height']) * 0.5
        edge = max(self.start_margin, self.safety_margin + 0.003)
        x_min = -L/2 + t + cut_x + hx + edge
        x_max =  L/2 - t - hx - edge
        start_x = min(max(tx, x_min), x_max)
        start_y = -W/2
        # Matches observed simulator collision centres: e.g. h=0.270 gives
        # 0.04 + 0.135 + 0.006 = 0.181 m.
        entry_z = t + hz + 0.006
        m = self.safety_margin

        for obj in packed:
            if obj.get('pos') is None:
                continue
            ox, oy, oz = self._local_pos(c, obj['pos'])
            ohx = float(obj['length']) * 0.5
            ohy = float(obj['width']) * 0.5
            ohz = float(obj['height']) * 0.5

            # Horizontal Y then X at the low entry height.
            if abs(entry_z - oz) < hz + ohz + m:
                ylo, yhi = sorted((start_y, ty))
                if (abs(start_x - ox) < hx + ohx + m and
                        oy + ohy + m > ylo and oy - ohy - m < yhi):
                    return False
                xlo, xhi = sorted((start_x, tx))
                if (abs(ty - oy) < hy + ohy + m and
                        ox + ohx + m > xlo and ox - ohx - m < xhi):
                    return False

            # Final vertical lift/drop at target XY.
            if abs(tx - ox) < hx + ohx + m and abs(ty - oy) < hy + ohy + m:
                zlo = min(entry_z, tz) - hz
                zhi = max(entry_z, tz) + hz
                if oz + ohz + m > zlo and oz - ohz - m < zhi:
                    return False
        return True

    def _path_clear_packed_only(self, c, item, target, packed):
        """Route test against movable/packed items only.

        Used by precedence construction. Fixed shelves are intentionally
        excluded because changing item order can never remove a shelf.
        """
        if self.cpp_checker is not None and self.cpp_mode != 'off':
            moving = self._cpp_box(item, (0.0, 0.0, 0.0))
            result = self.cpp_checker.check_transport_like_safe_grid(
                moving,
                self._cpp_container_bounds(c),
                self._cpp_packed_boxes(c, packed),
                float(target[0]), float(target[1]), float(target[2]),
                float(c.get('cut_x', 0.0)),
                float(c.get('thickness', 0.04)),
                float(self.start_margin),
                float(self.safety_margin),
                0.0,
                0.01,
                float(self.safety_margin),
            )
            self.cpp_stats['path_cpp'] += 1
            if not bool(result['ok']):
                return False
            return self._simulator_transport_packed_clear(c, item, target, packed)

        # Reuse the existing Python analytical implementation, but temporarily
        # skip static-shelf logic by calling the packed-item part inline.
        self.cpp_stats['python_fallback_path'] += 1
        tx, ty, tz = map(float, target)
        L, W = float(c['length']), float(c['width'])
        t = float(c.get('thickness', 0.04))
        cut_x = float(c.get('cut_x', 0.0))
        hx, hy, hz = float(item['length'])/2, float(item['width'])/2, float(item['height'])/2
        edge = max(self.start_margin, self.safety_margin + 0.003)
        x_min = -L/2 + t + cut_x + hx + edge
        x_max =  L/2 - t - hx - edge
        start_x = min(max(tx, x_min), x_max)
        start_y = -W/2
        floor_bottom = tz - hz
        path_z = tz if 0 <= floor_bottom-t <= 0.05 else min(
            tz + 0.08,
            float(c['height']) - t - hz - self.start_margin,
        )
        m = self.safety_margin
        for obj in packed:
            if obj.get('pos') is None:
                continue
            ox, oy, oz = self._local_pos(c, obj['pos'])
            ohx, ohy, ohz = float(obj['length'])/2, float(obj['width'])/2, float(obj['height'])/2
            if abs(path_z-oz) >= hz+ohz+m:
                continue
            # Y segment
            if abs(start_x-ox) < hx+ohx+m:
                lo, hi = sorted((start_y, ty))
                if oy + ohy + m > lo and oy - ohy - m < hi:
                    return False
            # X segment
            if abs(ty-oy) < hy+ohy+m:
                lo, hi = sorted((start_x, tx))
                if ox + ohx + m > lo and ox - ohx - m < hi:
                    return False
        return True

    def _path_clear(self, c, item, target, packed):
        if self.cpp_checker is not None and self.cpp_mode != 'off':
            moving = self._cpp_box(item, (0.0, 0.0, 0.0))
            result = self.cpp_checker.check_transport_like_safe_grid(
                moving,
                self._cpp_container_bounds(c),
                self._cpp_packed_boxes(c, packed),
                float(target[0]), float(target[1]), float(target[2]),
                float(c.get('cut_x', 0.0)),
                float(c.get('thickness', 0.04)),
                float(self.start_margin),
                float(self.safety_margin),
                0.0,
                0.01,
                float(self.safety_margin),
            )
            self.cpp_stats['path_cpp'] += 1
            if not bool(result['ok']):
                return False
            if not self._simulator_transport_packed_clear(c, item, target, packed):
                return False
            # Fixed shelves are static obstacles and are checked separately.
            return self._static_shelf_path_clear(c, item, target)

        # Python fallback: same analytical two-segment approximation used in
        # safe_grid before C++ authority.
        self.cpp_stats['python_fallback_path'] += 1
        tx, ty, tz = map(float, target)
        L, W = float(c['length']), float(c['width'])
        t = float(c.get('thickness', 0.04))
        cut_x = float(c.get('cut_x', 0.0))
        hx, hy, hz = float(item['length'])/2, float(item['width'])/2, float(item['height'])/2
        x_min = -L/2 + t + cut_x + hx + max(self.start_margin, self.safety_margin + 0.003)
        x_max =  L/2 - t - hx - max(self.start_margin, self.safety_margin + 0.003)
        start_x = min(max(tx, x_min), x_max)
        start_y = -W/2

        floor_bottom = tz - hz
        path_z = tz if 0 <= floor_bottom-t <= 0.05 else min(
            tz + 0.08,
            float(c['height']) - t - hz - self.start_margin,
        )
        m = self.safety_margin
        for obj in packed:
            if obj.get('pos') is None:
                continue
            ox, oy, oz = self._local_pos(c, obj['pos'])
            ohx, ohy, ohz = float(obj['length'])/2, float(obj['width'])/2, float(obj['height'])/2
            if abs(path_z-oz) >= hz+ohz+m:
                continue
            ylo, yhi = sorted((start_y, ty))
            if abs(start_x-ox) < hx+ohx+m and not (yhi+hy <= oy-ohy-m or ylo-hy >= oy+ohy+m):
                return False
            xlo, xhi = sorted((start_x, tx))
            if abs(ty-oy) < hy+ohy+m and not (xhi+hx <= ox-ohx-m or xlo-hx >= ox+ohx+m):
                return False
        return True

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _local_pos(self, c, world_pos):
        # Exact inverse of simulator Container.global_to_local(): only X has
        # a per-container offset. Y and Z stay unchanged.
        center = c.get('center', (0.0, 0.0, 0.0))
        return (
            float(world_pos[0]) - float(center[0]),
            float(world_pos[1]),
            float(world_pos[2]),
        )

    def _safe_abort_no_transport(self, container=None, pool=None, reason='UNKNOWN'):
        """Terminate cleanly before transport when no safe action exists.

        The environment has no skip/no-op action.  Returning an ordinary fallback
        pose would make PyBullet physically transport an unplanned/unsafe item and
        can collide with already packed cargo.  Instead, v5 deliberately returns
        an out-of-container target so PlacementValidator.check_inclusion() rejects
        the action before check_transport_path()/place_item() are called.

        This is an explicit terminal action, not a packing heuristic.
        """
        if container is None or pool is None:
            return {
                'item_idx': 0,
                'container_idx': 0,
                'place_pos': np.asarray((100.0, 100.0, 100.0), dtype=np.float32),
                'orientation': 0,
            }

        item = pool[0]
        L = float(container.get('length', 0.0))
        W = float(container.get('width', 0.0))
        H = float(container.get('height', 0.0))
        # Put the item center far outside +X.  Keep Y/Z finite and action-valid;
        # inclusion must fail before any transport takes place.
        abort_x = max(2.0, L + float(item.get('length', 0.0)) + 1.0)
        abort_pos = (abort_x, 0.0, max(0.1, H * 0.5))
        print(
            f'[search_cand_v5][SAFE-ABORT] step={self.step_no} reason={reason} '
            f'item={int(item.get("index", -1))} '
            f'target=({abort_pos[0]:.3f},{abort_pos[1]:.3f},{abort_pos[2]:.3f}) '
            f'expected=INCLUSION-REJECT-NO-TRANSPORT',
            flush=True,
        )
        return {
            'item_idx': 0,
            'container_idx': 0,
            'place_pos': np.asarray(abort_pos, dtype=np.float32),
            'orientation': 0,
        }

    def _planned_layout_last_resort(self, visible_plans, pool_index_by_id, containers, pool):
        """Last resort that never invents a non-BPP target.

        The simulator API has no no-op action.  If insertion constraints leave
        no safe candidate, preserve the 3D-BPP target instead of falling back
        to the historical centre-of-container pose.  This is intentionally loud
        in logs so remaining insertion-model gaps are easy to diagnose.
        """
        order_rank = {}
        if self.precedence_graph is not None:
            order_rank = {int(i): r for r, i in enumerate(self.precedence_graph.get('order', []))}

        # Never use LAST-RESORT for a plan whose fixed BPP target is blocked by
        # a static shelf. Reordering cannot make that path reachable.
        diag = getattr(self.insertion_planner, 'last_runtime_diagnostics', {}) or {}
        static_blocked = set(int(x) for x in diag.get('static_blocked_ids', []))
        candidates = [p for p in visible_plans if int(p['item_id']) not in static_blocked]
        if not candidates:
            print(
                f'[search_cand_v5][INSERT-NO-NONSTATIC-LAST-RESORT] '
                f'static_blocked={sorted(static_blocked)} '
                f'visible={[int(q["item_id"]) for q in visible_plans]}',
                flush=True,
            )
            # The simulator API has no no-op. Keep the old fallback only for
            # this degenerate all-static-blocked state; importantly, do not mark
            # any BPP plan executed or pretend its target was reachable.
            return self._safe_abort_no_transport(containers[0], pool, reason='ALL-STATIC-BLOCKED')

        for p in sorted(candidates, key=lambda q: (
            order_rank.get(int(q['item_id']), 10**9),
            int(q.get('plan_rank', 10**9)), int(q['item_id']))):
            iid = int(p['item_id'])
            cidx = int(p['container_idx'])
            final = tuple(float(v) for v in p['final_target'])
            execution, lift = self.insertion_planner.execution_target(p)
            execution = self._clamp_to_safe_margin(
                containers[cidx], p['item'], execution, int(p['orientation']))
            occupied = self._effective_packed(cidx, containers[cidx])
            if not self._validator_aligned_runtime_path_clear(
                    containers[cidx], p['item'], execution, occupied):
                print(f'[serch_cand_v7][LAST-RESORT-SKIP] item={iid} blocked', flush=True)
                continue
            self.executed_ids.add(iid)
            self.placed_orientation[iid] = int(p['orientation'])
            self._record_internal_placement(cidx, containers[cidx], p['item'], final, int(p['orientation']))
            print(f'[serch_cand_v7][LAST-RESORT] item={iid} safe-path confirmed', flush=True)
            return {
                'item_idx': int(pool_index_by_id[iid]),
                'container_idx': cidx,
                'place_pos': np.asarray(execution, dtype=np.float32),
                'orientation': int(p['orientation']),
            }
        return self._safe_abort_no_transport(containers[0], pool, reason='ALL-ROUTES-BLOCKED')

    def _fallback(self, container=None, item=None):
        z = 0.1
        if container is not None and item is not None:
            z = float(container.get('thickness', 0.04)) + float(item['height'])/2 + 0.006
        print(
            f'[search_cand_v5] mode=NO-FEASIBLE-CANDIDATE '
            f'target=(0.000,0.000,{z:.3f}) stats={self.cpp_stats}'
        )
        return {
            'item_idx': 0,
            'container_idx': 0,
            'place_pos': np.asarray((0.0, 0.0, z), dtype=np.float32),
            'orientation': 0,
        }

