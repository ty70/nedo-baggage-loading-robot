# v17 物理beamサーチ・ローカル検証用

Python 3.12 / Linux x86_64が必要です。v15と同じ.soを同梱しています。
ZIPをシミュレータのagents/へ展開し、agents/v17_submit/agent.pyの配置にします。
既存v15/v16を上書きしません。実行時コンパイルや追加インストールは行いません。
NumPyとPyBulletがインストール済みのPython 3.12環境を使ってください。

物理判定には同梱した元シミュレータの荷物・コンテナ・判定・評価モデルを使用。
入力configから本番と同じvalidator設定を読みます。--config-pathがない実行では
SC_PHYSICS_CONFIGで設定ファイルを指定してください。提出先への適合は未検証です。

シミュレータのルートで：

```bash
python --version
python -m scripts.run_test_visual \
  --config-path cases/101.json \
  --module-path agents/v17_submit/ \
  --result-dir results/v17_actual_101/ \
  --result-fname evaluation.json \
  --verbose True --render-mode human
```

配置計画と物理候補の診断も保存する場合は、実行前に：

```bash
export EP_NEED_3D_BPP="$PWD/results/v17_actual_101/bpp_layout.json"
```

同じ結果フォルダは再使用せず、実行ごとに新しいresult-dirへ保存してください。
既定値：beam8、次の荷物8候補、幾何候補16、成功配置2、optimize予算60秒、policy予算2秒。
追加荷重後の全荷物の位置・姿勢・速度を枝へ引き継ぎ、搬入・定着の成功候補だけ保持します。
ただし内部接触キャッシュは複製せず、観測にない初期速度はゼロで推定します。

6課題の基準測定ではv15より積載数が少なく、改善版としては未採用です。
101/103/000は10個、112/123/001は6個でした。詳細と評価JSONを同梱しています。
本ZIPは検証用であり、提出版を自動で置き換えるものではありません。
